"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  BookOpen,
  Play,
  TrendingUp,
  Trophy,
  PlusCircle,
  Clock,
  CheckCircle2,
  XCircle,
  LogIn,
} from "lucide-react";
import { formatDate } from "@/lib/utils";

interface Stats {
  created: number;
  played: number;
  avgScore: string;
  leaderboardScore: number;
}

interface RecentResult {
  id: number;
  score: number;
  totalMarks: number;
  percentage: number;
  passed: boolean;
  createdAt: string;
  quizTitle: string | null;
}

export default function DashboardPage() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [results, setResults] = useState<RecentResult[]>([]);
  const [loading, setLoading] = useState(true);
  const [username, setUsername] = useState("");
  const [authed, setAuthed] = useState<boolean | null>(null); // null = checking

  useEffect(() => {
    // Check auth first
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (!d.user) {
          setAuthed(false);
          setLoading(false);
          return;
        }
        setAuthed(true);
        setUsername(d.user.username);

        // Now fetch dashboard data
        return fetch("/api/dashboard")
          .then((r) => r.json())
          .then((d) => {
            setStats(d.stats);
            setResults(d.recentResults || []);
          });
      })
      .catch(() => {
        setAuthed(false);
      })
      .finally(() => setLoading(false));
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  // Not logged in – show message instead of auto-redirect
  if (authed === false) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center"
        >
          <LogIn className="w-16 h-16 text-primary mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Login Required</h2>
          <p className="text-text-secondary mb-6">
            Please sign in to access your dashboard
          </p>
          <Link
            href="/login"
            className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-primary to-primary-hover text-white font-semibold hover:shadow-lg hover:shadow-primary/25 transition-all"
          >
            <LogIn className="w-5 h-5" />
            Sign In
          </Link>
        </motion.div>
      </div>
    );
  }

  const statCards = [
    {
      icon: BookOpen,
      label: "Quizzes Created",
      value: stats?.created || 0,
      color: "text-primary",
      bg: "bg-primary/10",
    },
    {
      icon: Play,
      label: "Quizzes Played",
      value: stats?.played || 0,
      color: "text-secondary",
      bg: "bg-secondary/10",
    },
    {
      icon: TrendingUp,
      label: "Average Score",
      value: `${stats?.avgScore || 0}%`,
      color: "text-success",
      bg: "bg-success/10",
    },
    {
      icon: Trophy,
      label: "Total Points",
      value: stats?.leaderboardScore || 0,
      color: "text-accent",
      bg: "bg-accent/10",
    },
  ];

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-6xl mx-auto">
        {/* Welcome */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-3xl font-bold mb-2">
            Welcome back, <span className="gradient-text">{username}</span>! 👋
          </h1>
          <p className="text-text-secondary">
            Here&apos;s an overview of your quiz activity
          </p>
        </motion.div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {statCards.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="p-5 rounded-2xl bg-card border border-border hover:border-primary/20 transition-all"
            >
              <div className="flex items-center gap-3 mb-3">
                <div
                  className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center`}
                >
                  <s.icon className={`w-5 h-5 ${s.color}`} />
                </div>
                <span className="text-sm text-text-secondary">{s.label}</span>
              </div>
              <p className="text-2xl font-bold">{s.value}</p>
            </motion.div>
          ))}
        </div>

        {/* Quick Actions + Recent */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Quick Actions */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.3 }}
            className="rounded-2xl bg-card border border-border p-6"
          >
            <h2 className="font-semibold text-lg mb-4">Quick Actions</h2>
            <div className="space-y-3">
              <Link
                href="/create"
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors group"
              >
                <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                  <PlusCircle className="w-5 h-5 text-primary" />
                </div>
                <div>
                  <p className="text-sm font-medium">Create Quiz</p>
                  <p className="text-xs text-text-muted">Build a new quiz</p>
                </div>
              </Link>
              <Link
                href="/explore"
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors group"
              >
                <div className="w-10 h-10 rounded-xl bg-secondary/10 flex items-center justify-center group-hover:bg-secondary/20 transition-colors">
                  <Play className="w-5 h-5 text-secondary" />
                </div>
                <div>
                  <p className="text-sm font-medium">Play Quiz</p>
                  <p className="text-xs text-text-muted">Explore quizzes</p>
                </div>
              </Link>
              <Link
                href="/leaderboard"
                className="flex items-center gap-3 p-3 rounded-xl hover:bg-white/5 transition-colors group"
              >
                <div className="w-10 h-10 rounded-xl bg-accent/10 flex items-center justify-center group-hover:bg-accent/20 transition-colors">
                  <Trophy className="w-5 h-5 text-accent" />
                </div>
                <div>
                  <p className="text-sm font-medium">Leaderboard</p>
                  <p className="text-xs text-text-muted">See rankings</p>
                </div>
              </Link>
            </div>
          </motion.div>

          {/* Recent Activity */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4 }}
            className="lg:col-span-2 rounded-2xl bg-card border border-border p-6"
          >
            <h2 className="font-semibold text-lg mb-4">Recent Activity</h2>
            {results.length === 0 ? (
              <div className="text-center py-8">
                <Clock className="w-12 h-12 text-text-muted mx-auto mb-3" />
                <p className="text-text-secondary text-sm">
                  No activity yet. Start by playing a quiz!
                </p>
              </div>
            ) : (
              <div className="space-y-3">
                {results.slice(0, 8).map((r) => (
                  <Link
                    key={r.id}
                    href={`/result/${r.id}`}
                    className="flex items-center gap-4 p-3 rounded-xl hover:bg-white/5 transition-colors"
                  >
                    <div
                      className={`w-10 h-10 rounded-xl flex items-center justify-center shrink-0 ${
                        r.passed ? "bg-success/10" : "bg-danger/10"
                      }`}
                    >
                      {r.passed ? (
                        <CheckCircle2 className="w-5 h-5 text-success" />
                      ) : (
                        <XCircle className="w-5 h-5 text-danger" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="text-sm font-medium truncate">
                        {r.quizTitle || "Quiz"}
                      </p>
                      <p className="text-xs text-text-muted">
                        {formatDate(r.createdAt)}
                      </p>
                    </div>
                    <div className="text-right">
                      <p
                        className={`text-sm font-semibold ${
                          r.passed ? "text-success" : "text-danger"
                        }`}
                      >
                        {r.percentage.toFixed(0)}%
                      </p>
                      <p className="text-xs text-text-muted">
                        {r.score}/{r.totalMarks}
                      </p>
                    </div>
                  </Link>
                ))}
              </div>
            )}
          </motion.div>
        </div>
      </div>
    </div>
  );
}

import { NextResponse } from "next/server";
import { db } from "@/db";
import { results, quizzes } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userResults = await db
      .select({
        id: results.id,
        score: results.score,
        totalMarks: results.totalMarks,
        correctAnswers: results.correctAnswers,
        wrongAnswers: results.wrongAnswers,
        skipped: results.skipped,
        timeTaken: results.timeTaken,
        percentage: results.percentage,
        passed: results.passed,
        answers: results.answers,
        createdAt: results.createdAt,
        quizId: quizzes.id,
        quizTitle: quizzes.title,
        quizDifficulty: quizzes.difficulty,
      })
      .from(results)
      .leftJoin(quizzes, eq(results.quizId, quizzes.id))
      .where(eq(results.userId, user.id))
      .orderBy(desc(results.createdAt))
      .limit(50);

    return NextResponse.json({ results: userResults });
  } catch (error) {
    console.error("Get results error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

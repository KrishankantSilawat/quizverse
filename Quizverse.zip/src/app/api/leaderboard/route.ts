import { NextResponse } from "next/server";
import { db } from "@/db";
import { leaderboard, users } from "@/db/schema";
import { desc } from "drizzle-orm";
import { eq } from "drizzle-orm";

export async function GET() {
  try {
    const leaders = await db
      .select({
        id: leaderboard.id,
        totalScore: leaderboard.totalScore,
        quizzesPlayed: leaderboard.quizzesPlayed,
        accuracy: leaderboard.accuracy,
        username: users.username,
        avatar: users.avatar,
        userId: users.id,
      })
      .from(leaderboard)
      .leftJoin(users, eq(leaderboard.userId, users.id))
      .orderBy(desc(leaderboard.totalScore))
      .limit(50);

    return NextResponse.json({ leaderboard: leaders });
  } catch (error) {
    console.error("Get leaderboard error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { results, quizzes, questions } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const resultId = parseInt(id);

    const [result] = await db
      .select({
        id: results.id,
        score: results.score,
        totalMarks: results.totalMarks,
        correctAnswers: results.correctAnswers,
        wrongAnswers: results.wrongAnswers,
        skipped: results.skipped,
        timeTaken: results.timeTaken,
        percentage: results.percentage,
        passed: results.passed,
        answers: results.answers,
        createdAt: results.createdAt,
        quizId: quizzes.id,
        quizTitle: quizzes.title,
      })
      .from(results)
      .leftJoin(quizzes, eq(results.quizId, quizzes.id))
      .where(eq(results.id, resultId))
      .limit(1);

    if (!result) {
      return NextResponse.json({ error: "Result not found" }, { status: 404 });
    }

    // Get quiz questions for review
    const quizQuestions = result.quizId
      ? await db
          .select()
          .from(questions)
          .where(eq(questions.quizId, result.quizId))
          .orderBy(questions.orderIndex)
      : [];

    return NextResponse.json({ result, questions: quizQuestions });
  } catch (error) {
    console.error("Get result error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

"use client";

import { useState, useEffect } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Users,
  BookOpen,
  BarChart3,
  FolderOpen,
  Shield,
  Ban,
  CheckCircle2,
  Trash2,
  User,
  LogIn,
} from "lucide-react";
import { formatDate } from "@/lib/utils";

interface AdminStats {
  users: number;
  quizzes: number;
  results: number;
  categories: number;
}

interface AdminUser {
  id: number;
  username: string;
  email: string;
  role: string;
  banned: boolean;
  createdAt: string;
}

interface AdminQuiz {
  id: number;
  title: string;
  published: boolean;
  attempts: number;
  creatorName: string | null;
  createdAt: string;
}

export default function AdminPage() {
  const [stats, setStats] = useState<AdminStats | null>(null);
  const [userList, setUserList] = useState<AdminUser[]>([]);
  const [quizzes, setQuizzes] = useState<AdminQuiz[]>([]);
  const [loading, setLoading] = useState(true);
  const [tab, setTab] = useState<"users" | "quizzes">("users");
  const [authed, setAuthed] = useState<boolean | null>(null);

  useEffect(() => {
    fetch("/api/auth/me")
      .then((r) => r.json())
      .then((d) => {
        if (!d.user || d.user.role !== "admin") {
          setAuthed(false);
          setLoading(false);
          return;
        }
        setAuthed(true);

        return fetch("/api/admin/stats")
          .then((r) => r.json())
          .then((d) => {
            if (d.error) {
              setAuthed(false);
              return;
            }
            setStats(d.stats);
            setUserList(d.recentUsers || []);
            setQuizzes(d.recentQuizzes || []);
          });
      })
      .catch(() => setAuthed(false))
      .finally(() => setLoading(false));
  }, []);

  const toggleBan = async (userId: number, currentBanned: boolean) => {
    await fetch(`/api/admin/users/${userId}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ banned: !currentBanned }),
    });
    setUserList(
      userList.map((u) =>
        u.id === userId ? { ...u, banned: !currentBanned } : u
      )
    );
  };

  const deleteQuiz = async (quizId: number) => {
    await fetch(`/api/quizzes/${quizId}`, { method: "DELETE" });
    setQuizzes(quizzes.filter((q) => q.id !== quizId));
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (authed === false) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} className="text-center">
          <Shield className="w-16 h-16 text-accent mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Admin Access Required</h2>
          <p className="text-text-secondary mb-6">You need admin privileges to access this page</p>
          <Link href="/login" className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-primary to-primary-hover text-white font-semibold hover:shadow-lg hover:shadow-primary/25 transition-all">
            <LogIn className="w-5 h-5" /> Sign In
          </Link>
        </motion.div>
      </div>
    );
  }

  const statCards = [
    { icon: Users, label: "Total Users", value: stats?.users || 0, color: "text-primary", bg: "bg-primary/10" },
    { icon: BookOpen, label: "Total Quizzes", value: stats?.quizzes || 0, color: "text-secondary", bg: "bg-secondary/10" },
    { icon: BarChart3, label: "Total Results", value: stats?.results || 0, color: "text-success", bg: "bg-success/10" },
    { icon: FolderOpen, label: "Categories", value: stats?.categories || 0, color: "text-accent", bg: "bg-accent/10" },
  ];

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-6xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-2">
            <Shield className="w-8 h-8 text-accent" />
            <h1 className="text-3xl font-bold">Admin Panel</h1>
          </div>
          <p className="text-text-secondary">
            Manage users, quizzes, and platform settings
          </p>
        </motion.div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
          {statCards.map((s, i) => (
            <motion.div
              key={s.label}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.1 }}
              className="p-5 rounded-2xl bg-card border border-border"
            >
              <div className={`w-10 h-10 rounded-xl ${s.bg} flex items-center justify-center mb-3`}>
                <s.icon className={`w-5 h-5 ${s.color}`} />
              </div>
              <p className="text-2xl font-bold">{s.value}</p>
              <p className="text-xs text-text-muted">{s.label}</p>
            </motion.div>
          ))}
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6">
          <button
            onClick={() => setTab("users")}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              tab === "users" ? "bg-primary/10 text-primary" : "text-text-secondary hover:text-white"
            }`}
          >
            <Users className="w-4 h-4 inline mr-2" />
            Users
          </button>
          <button
            onClick={() => setTab("quizzes")}
            className={`px-4 py-2 rounded-xl text-sm font-medium transition-all ${
              tab === "quizzes" ? "bg-primary/10 text-primary" : "text-text-secondary hover:text-white"
            }`}
          >
            <BookOpen className="w-4 h-4 inline mr-2" />
            Quizzes
          </button>
        </div>

        {/* Content */}
        <motion.div
          key={tab}
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl bg-card border border-border overflow-hidden"
        >
          {tab === "users" ? (
            <div className="divide-y divide-border">
              {userList.map((u) => (
                <div key={u.id} className="flex items-center gap-4 p-4 hover:bg-white/[0.02]">
                  <div className="w-10 h-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                    <User className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{u.username}</p>
                    <p className="text-xs text-text-muted">{u.email}</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-xs ${u.role === "admin" ? "bg-accent/10 text-accent" : "bg-white/5 text-text-muted"}`}>
                    {u.role}
                  </span>
                  <span className="text-xs text-text-muted hidden sm:block">{formatDate(u.createdAt)}</span>
                  <button
                    onClick={() => toggleBan(u.id, u.banned)}
                    className={`p-2 rounded-lg transition-colors ${
                      u.banned ? "text-success hover:bg-success/10" : "text-danger hover:bg-danger/10"
                    }`}
                    title={u.banned ? "Unban" : "Ban"}
                  >
                    {u.banned ? <CheckCircle2 className="w-4 h-4" /> : <Ban className="w-4 h-4" />}
                  </button>
                </div>
              ))}
              {userList.length === 0 && (
                <div className="p-8 text-center text-text-muted">No users</div>
              )}
            </div>
          ) : (
            <div className="divide-y divide-border">
              {quizzes.map((q) => (
                <div key={q.id} className="flex items-center gap-4 p-4 hover:bg-white/[0.02]">
                  <div className="w-10 h-10 rounded-xl bg-secondary/10 flex items-center justify-center shrink-0">
                    <BookOpen className="w-5 h-5 text-secondary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="font-medium text-sm truncate">{q.title}</p>
                    <p className="text-xs text-text-muted">by {q.creatorName || "Unknown"}</p>
                  </div>
                  <span className={`px-2 py-0.5 rounded text-xs ${q.published ? "bg-success/10 text-success" : "bg-warning/10 text-warning"}`}>
                    {q.published ? "Published" : "Draft"}
                  </span>
                  <span className="text-xs text-text-muted hidden sm:block">{q.attempts} plays</span>
                  <button
                    onClick={() => deleteQuiz(q.id)}
                    className="p-2 rounded-lg text-danger hover:bg-danger/10 transition-colors"
                    title="Delete"
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              ))}
              {quizzes.length === 0 && (
                <div className="p-8 text-center text-text-muted">No quizzes</div>
              )}
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

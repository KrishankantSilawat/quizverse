import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { quizzes, questions, users, categories } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq } from "drizzle-orm";

export async function GET(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const { id } = await params;
    const quizId = parseInt(id);

    const [quiz] = await db
      .select({
        id: quizzes.id,
        title: quizzes.title,
        description: quizzes.description,
        difficulty: quizzes.difficulty,
        timeLimit: quizzes.timeLimit,
        coverImage: quizzes.coverImage,
        published: quizzes.published,
        attempts: quizzes.attempts,
        rating: quizzes.rating,
        createdAt: quizzes.createdAt,
        creatorId: quizzes.creatorId,
        creatorName: users.username,
        categoryName: categories.name,
        categoryId: quizzes.categoryId,
      })
      .from(quizzes)
      .leftJoin(users, eq(quizzes.creatorId, users.id))
      .leftJoin(categories, eq(quizzes.categoryId, categories.id))
      .where(eq(quizzes.id, quizId))
      .limit(1);

    if (!quiz) {
      return NextResponse.json({ error: "Quiz not found" }, { status: 404 });
    }

    const quizQuestions = await db
      .select()
      .from(questions)
      .where(eq(questions.quizId, quizId))
      .orderBy(questions.orderIndex);

    return NextResponse.json({ quiz, questions: quizQuestions });
  } catch (error) {
    console.error("Get quiz error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function PUT(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const quizId = parseInt(id);
    const body = await req.json();

    // Check ownership
    const [existing] = await db
      .select()
      .from(quizzes)
      .where(eq(quizzes.id, quizId))
      .limit(1);

    if (!existing) {
      return NextResponse.json({ error: "Quiz not found" }, { status: 404 });
    }

    if (existing.creatorId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const { questionList, ...quizData } = body;

    await db
      .update(quizzes)
      .set({
        ...quizData,
        updatedAt: new Date(),
      })
      .where(eq(quizzes.id, quizId));

    if (questionList) {
      await db.delete(questions).where(eq(questions.quizId, quizId));
      if (questionList.length > 0) {
        const qValues = questionList.map(
          (
            q: {
              question: string;
              optionA: string;
              optionB: string;
              optionC: string;
              optionD: string;
              correctAnswer: string;
              explanation: string;
              marks: number;
              negativeMark: number;
            },
            i: number
          ) => ({
            quizId,
            question: q.question,
            optionA: q.optionA,
            optionB: q.optionB,
            optionC: q.optionC || "",
            optionD: q.optionD || "",
            correctAnswer: q.correctAnswer,
            explanation: q.explanation || "",
            marks: q.marks || 1,
            negativeMark: q.negativeMark || 0,
            orderIndex: i,
          })
        );
        await db.insert(questions).values(qValues);
      }
    }

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Update quiz error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function DELETE(
  _req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const quizId = parseInt(id);

    const [existing] = await db
      .select()
      .from(quizzes)
      .where(eq(quizzes.id, quizId))
      .limit(1);

    if (!existing) {
      return NextResponse.json({ error: "Quiz not found" }, { status: 404 });
    }

    if (existing.creatorId !== user.id && user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    await db.delete(quizzes).where(eq(quizzes.id, quizId));

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error("Delete quiz error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

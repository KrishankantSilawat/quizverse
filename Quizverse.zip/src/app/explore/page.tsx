"use client";

import { useState, useEffect, useCallback } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Search,
  Filter,
  Clock,
  Users,
  Star,
  ChevronLeft,
  ChevronRight,
  BookOpen,
} from "lucide-react";

interface Quiz {
  id: number;
  title: string;
  description: string | null;
  difficulty: string | null;
  timeLimit: number | null;
  attempts: number;
  rating: number | null;
  creatorName: string | null;
  categoryName: string | null;
  questionCount: number;
  createdAt: string;
}

export default function ExplorePage() {
  const [quizzes, setQuizzes] = useState<Quiz[]>([]);
  const [search, setSearch] = useState("");
  const [difficulty, setDifficulty] = useState("");
  const [sort, setSort] = useState("newest");
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [loading, setLoading] = useState(true);

  const fetchQuizzes = useCallback(async () => {
    setLoading(true);
    try {
      const params = new URLSearchParams({
        page: page.toString(),
        limit: "12",
        sort,
      });
      if (search) params.set("search", search);
      if (difficulty) params.set("difficulty", difficulty);

      const res = await fetch(`/api/quizzes?${params}`);
      const data = await res.json();
      setQuizzes(data.quizzes || []);
      setTotalPages(data.totalPages || 1);
    } catch {
      setQuizzes([]);
    } finally {
      setLoading(false);
    }
  }, [page, search, difficulty, sort]);

  useEffect(() => {
    const timer = setTimeout(() => fetchQuizzes(), 300);
    return () => clearTimeout(timer);
  }, [fetchQuizzes]);

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-7xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <h1 className="text-3xl sm:text-4xl font-bold mb-3">
            Explore <span className="gradient-text">Quizzes</span>
          </h1>
          <p className="text-text-secondary">
            Find and play quizzes from the community
          </p>
        </motion.div>

        {/* Filters */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="flex flex-col sm:flex-row gap-3 mb-8"
        >
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-text-muted" />
            <input
              type="text"
              value={search}
              onChange={(e) => {
                setSearch(e.target.value);
                setPage(1);
              }}
              placeholder="Search quizzes..."
              className="w-full pl-11 pr-4 py-3 rounded-xl bg-card border border-border focus:border-primary outline-none text-white placeholder-text-muted transition-all text-sm"
            />
          </div>

          <div className="flex gap-3">
            <div className="relative">
              <Filter className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-text-muted" />
              <select
                value={difficulty}
                onChange={(e) => {
                  setDifficulty(e.target.value);
                  setPage(1);
                }}
                className="pl-10 pr-8 py-3 rounded-xl bg-card border border-border focus:border-primary outline-none text-white text-sm appearance-none cursor-pointer"
              >
                <option value="">All Difficulty</option>
                <option value="easy">Easy</option>
                <option value="medium">Medium</option>
                <option value="hard">Hard</option>
              </select>
            </div>

            <select
              value={sort}
              onChange={(e) => {
                setSort(e.target.value);
                setPage(1);
              }}
              className="px-4 py-3 rounded-xl bg-card border border-border focus:border-primary outline-none text-white text-sm appearance-none cursor-pointer"
            >
              <option value="newest">Newest</option>
              <option value="popular">Popular</option>
              <option value="rating">Top Rated</option>
            </select>
          </div>
        </motion.div>

        {/* Quiz Grid */}
        {loading ? (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array.from({ length: 6 }).map((_, i) => (
              <div
                key={i}
                className="rounded-2xl bg-card border border-border p-6"
              >
                <div className="skeleton h-4 w-20 rounded mb-4" />
                <div className="skeleton h-6 w-3/4 rounded mb-3" />
                <div className="skeleton h-4 w-full rounded mb-2" />
                <div className="skeleton h-4 w-2/3 rounded mb-4" />
                <div className="skeleton h-3 w-1/2 rounded" />
              </div>
            ))}
          </div>
        ) : quizzes.length === 0 ? (
          <div className="text-center py-20">
            <BookOpen className="w-16 h-16 text-text-muted mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No quizzes found</h3>
            <p className="text-text-secondary">
              Try adjusting your search or filters
            </p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {quizzes.map((quiz, i) => (
              <motion.div
                key={quiz.id}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: i * 0.05 }}
              >
                <Link
                  href={`/quiz/${quiz.id}`}
                  className="group block p-6 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-xl hover:shadow-primary/5 h-full"
                >
                  <div className="flex items-start justify-between mb-4">
                    <span className="px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                      {quiz.categoryName || "General"}
                    </span>
                    <span
                      className={`px-3 py-1 rounded-full text-xs font-medium ${
                        quiz.difficulty === "hard"
                          ? "bg-danger/10 text-danger"
                          : quiz.difficulty === "easy"
                          ? "bg-success/10 text-success"
                          : "bg-accent/10 text-accent"
                      }`}
                    >
                      {quiz.difficulty}
                    </span>
                  </div>

                  <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors line-clamp-2">
                    {quiz.title}
                  </h3>
                  <p className="text-sm text-text-secondary line-clamp-2 mb-4">
                    {quiz.description || "No description provided"}
                  </p>

                  <div className="flex items-center gap-4 text-xs text-text-muted mb-3">
                    <span className="flex items-center gap-1">
                      <BookOpen className="w-3.5 h-3.5" />
                      {quiz.questionCount} questions
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-3.5 h-3.5" />
                      {Math.floor((quiz.timeLimit || 600) / 60)}m
                    </span>
                  </div>

                  <div className="flex items-center justify-between pt-3 border-t border-border">
                    <span className="text-xs text-text-muted flex items-center gap-1">
                      <Users className="w-3.5 h-3.5" />
                      {quiz.attempts} plays
                    </span>
                    <span className="text-xs text-text-muted flex items-center gap-1">
                      <Star className="w-3.5 h-3.5" />
                      {(quiz.rating || 0).toFixed(1)}
                    </span>
                    <span className="text-xs text-text-muted">
                      by {quiz.creatorName || "Unknown"}
                    </span>
                  </div>
                </Link>
              </motion.div>
            ))}
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="flex items-center justify-center gap-3 mt-10">
            <button
              onClick={() => setPage((p) => Math.max(1, p - 1))}
              disabled={page === 1}
              className="p-2 rounded-xl bg-card border border-border hover:border-primary/30 disabled:opacity-30 transition-all"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <span className="text-sm text-text-secondary px-4">
              Page {page} of {totalPages}
            </span>
            <button
              onClick={() => setPage((p) => Math.min(totalPages, p + 1))}
              disabled={page === totalPages}
              className="p-2 rounded-xl bg-card border border-border hover:border-primary/30 disabled:opacity-30 transition-all"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        )}
      </div>
    </div>
  );
}

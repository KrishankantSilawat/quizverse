"use client";

import { useState, useEffect, use } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Clock,
  BookOpen,
  Users,
  Star,
  Play,
  ArrowLeft,
  AlertCircle,
} from "lucide-react";

interface QuizData {
  id: number;
  title: string;
  description: string | null;
  difficulty: string | null;
  timeLimit: number | null;
  attempts: number;
  rating: number | null;
  creatorName: string | null;
  categoryName: string | null;
  published: boolean;
}

export default function QuizDetailPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const [quiz, setQuiz] = useState<QuizData | null>(null);
  const [questionCount, setQuestionCount] = useState(0);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/quizzes/${id}`)
      .then((r) => r.json())
      .then((d) => {
        setQuiz(d.quiz);
        setQuestionCount(d.questions?.length || 0);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!quiz) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-text-muted mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">Quiz Not Found</h2>
          <Link href="/explore" className="text-primary hover:underline">
            Browse quizzes
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <Link
          href="/explore"
          className="inline-flex items-center gap-2 text-text-secondary hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Explore
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl bg-card border border-border overflow-hidden"
        >
          {/* Header gradient */}
          <div className="h-32 bg-gradient-to-br from-primary/20 to-secondary/20 relative">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_30%_50%,rgba(108,99,255,0.15),transparent)]" />
          </div>

          <div className="p-6 sm:p-8 -mt-8">
            <div className="flex items-start gap-3 mb-4">
              <span className="px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                {quiz.categoryName || "General"}
              </span>
              <span
                className={`px-3 py-1 rounded-full text-xs font-medium ${
                  quiz.difficulty === "hard"
                    ? "bg-danger/10 text-danger"
                    : quiz.difficulty === "easy"
                    ? "bg-success/10 text-success"
                    : "bg-accent/10 text-accent"
                }`}
              >
                {quiz.difficulty}
              </span>
            </div>

            <h1 className="text-2xl sm:text-3xl font-bold mb-3">
              {quiz.title}
            </h1>
            <p className="text-text-secondary mb-6">
              {quiz.description || "No description provided"}
            </p>

            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
              <div className="p-4 rounded-xl bg-bg border border-border text-center">
                <BookOpen className="w-5 h-5 text-primary mx-auto mb-2" />
                <p className="text-lg font-bold">{questionCount}</p>
                <p className="text-xs text-text-muted">Questions</p>
              </div>
              <div className="p-4 rounded-xl bg-bg border border-border text-center">
                <Clock className="w-5 h-5 text-secondary mx-auto mb-2" />
                <p className="text-lg font-bold">
                  {Math.floor((quiz.timeLimit || 600) / 60)}m
                </p>
                <p className="text-xs text-text-muted">Time Limit</p>
              </div>
              <div className="p-4 rounded-xl bg-bg border border-border text-center">
                <Users className="w-5 h-5 text-accent mx-auto mb-2" />
                <p className="text-lg font-bold">{quiz.attempts}</p>
                <p className="text-xs text-text-muted">Attempts</p>
              </div>
              <div className="p-4 rounded-xl bg-bg border border-border text-center">
                <Star className="w-5 h-5 text-yellow-400 mx-auto mb-2" />
                <p className="text-lg font-bold">
                  {(quiz.rating || 0).toFixed(1)}
                </p>
                <p className="text-xs text-text-muted">Rating</p>
              </div>
            </div>

            <div className="flex items-center justify-between">
              <p className="text-sm text-text-muted">
                Created by{" "}
                <span className="text-white font-medium">
                  {quiz.creatorName || "Unknown"}
                </span>
              </p>
              <Link
                href={`/quiz/${quiz.id}/play`}
                className="flex items-center gap-2 px-8 py-3 rounded-xl bg-gradient-to-r from-primary to-primary-hover text-white font-semibold hover:shadow-lg hover:shadow-primary/25 transition-all transform hover:scale-105"
              >
                <Play className="w-5 h-5" />
                Start Quiz
              </Link>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}

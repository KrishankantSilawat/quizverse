"use client";

import { useState, useEffect, useCallback, use } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  Clock,
  ChevronLeft,
  ChevronRight,
  Flag,
  Send,
  SkipForward,
  AlertCircle,
} from "lucide-react";

interface Question {
  id: number;
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  marks: number | null;
}

export default function QuizPlayPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const [questions, setQuestions] = useState<Question[]>([]);
  const [currentQ, setCurrentQ] = useState(0);
  const [answers, setAnswers] = useState<Record<string, string>>({});
  const [flagged, setFlagged] = useState<Set<number>>(new Set());
  const [timeLeft, setTimeLeft] = useState(600);
  const [loading, setLoading] = useState(true);
  const [submitting, setSubmitting] = useState(false);
  const [startTime] = useState(Date.now());
  const [showPalette, setShowPalette] = useState(false);

  useEffect(() => {
    fetch(`/api/quizzes/${id}`)
      .then((r) => r.json())
      .then((d) => {
        setQuestions(d.questions || []);
        setTimeLeft(d.quiz?.timeLimit || 600);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [id]);

  const handleSubmit = useCallback(async () => {
    if (submitting) return;
    setSubmitting(true);
    const timeTaken = Math.floor((Date.now() - startTime) / 1000);
    try {
      const res = await fetch(`/api/quizzes/${id}/submit`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ answers, timeTaken }),
      });
      const data = await res.json();
      if (res.ok) {
        window.location.href = `/result/${data.result.id}`;
      }
    } catch {
      setSubmitting(false);
    }
  }, [id, answers, startTime, submitting]);

  // Timer
  useEffect(() => {
    if (loading || questions.length === 0) return;
    const interval = setInterval(() => {
      setTimeLeft((t) => {
        if (t <= 1) {
          clearInterval(interval);
          handleSubmit();
          return 0;
        }
        return t - 1;
      });
    }, 1000);
    return () => clearInterval(interval);
  }, [loading, questions.length, handleSubmit]);

  // Keyboard navigation
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === "ArrowRight" && currentQ < questions.length - 1) {
        setCurrentQ((c) => c + 1);
      } else if (e.key === "ArrowLeft" && currentQ > 0) {
        setCurrentQ((c) => c - 1);
      } else if (e.key >= "1" && e.key <= "4") {
        const opts = ["A", "B", "C", "D"];
        const q = questions[currentQ];
        if (q) {
          setAnswers((a) => ({ ...a, [q.id.toString()]: opts[parseInt(e.key) - 1] }));
        }
      }
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [currentQ, questions]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (questions.length === 0) {
    return (
      <div className="min-h-screen flex items-center justify-center px-4">
        <div className="text-center">
          <AlertCircle className="w-16 h-16 text-text-muted mx-auto mb-4" />
          <h2 className="text-2xl font-bold mb-2">No Questions</h2>
          <p className="text-text-secondary">This quiz has no questions yet.</p>
        </div>
      </div>
    );
  }

  const q = questions[currentQ];
  const progress = ((currentQ + 1) / questions.length) * 100;
  const minutes = Math.floor(timeLeft / 60);
  const seconds = timeLeft % 60;
  const isLowTime = timeLeft < 60;

  const toggleFlag = () => {
    setFlagged((f) => {
      const next = new Set(f);
      if (next.has(currentQ)) next.delete(currentQ);
      else next.add(currentQ);
      return next;
    });
  };

  return (
    <div className="min-h-screen px-4 py-6">
      <div className="max-w-4xl mx-auto">
        {/* Top Bar */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-4">
            <span className="text-sm text-text-secondary">
              Question {currentQ + 1} of {questions.length}
            </span>
            <button
              onClick={() => setShowPalette(!showPalette)}
              className="px-3 py-1.5 rounded-lg bg-card border border-border text-xs hover:border-primary/30 transition-all md:hidden"
            >
              Palette
            </button>
          </div>
          <div
            className={`flex items-center gap-2 px-4 py-2 rounded-xl ${
              isLowTime ? "bg-danger/10 text-danger" : "bg-card border border-border"
            }`}
          >
            <Clock className="w-4 h-4" />
            <span className="font-mono font-semibold">
              {minutes}:{seconds.toString().padStart(2, "0")}
            </span>
          </div>
        </div>

        {/* Progress Bar */}
        <div className="h-1.5 bg-card rounded-full mb-6 overflow-hidden">
          <motion.div
            className="h-full bg-gradient-to-r from-primary to-secondary rounded-full"
            initial={{ width: 0 }}
            animate={{ width: `${progress}%` }}
            transition={{ duration: 0.3 }}
          />
        </div>

        <div className="flex gap-6">
          {/* Question Card */}
          <div className="flex-1">
            <AnimatePresence mode="wait">
              <motion.div
                key={currentQ}
                initial={{ opacity: 0, x: 20 }}
                animate={{ opacity: 1, x: 0 }}
                exit={{ opacity: 0, x: -20 }}
                transition={{ duration: 0.2 }}
                className="rounded-2xl bg-card border border-border p-6 sm:p-8"
              >
                <div className="flex items-start justify-between mb-6">
                  <h2 className="text-lg sm:text-xl font-semibold pr-4">
                    {q.question}
                  </h2>
                  <button
                    onClick={toggleFlag}
                    className={`p-2 rounded-lg transition-colors shrink-0 ${
                      flagged.has(currentQ)
                        ? "bg-accent/10 text-accent"
                        : "hover:bg-white/5 text-text-muted"
                    }`}
                    title="Flag question"
                  >
                    <Flag className="w-5 h-5" />
                  </button>
                </div>

                <div className="space-y-3">
                  {(["A", "B", "C", "D"] as const).map((opt) => {
                    const val = q[`option${opt}` as keyof Question] as string;
                    if (!val) return null;
                    const selected = answers[q.id.toString()] === opt;
                    return (
                      <motion.button
                        key={opt}
                        whileHover={{ scale: 1.01 }}
                        whileTap={{ scale: 0.99 }}
                        onClick={() =>
                          setAnswers((a) => ({
                            ...a,
                            [q.id.toString()]: opt,
                          }))
                        }
                        className={`w-full text-left px-5 py-4 rounded-xl border transition-all duration-200 ${
                          selected
                            ? "border-primary bg-primary/10 text-white shadow-lg shadow-primary/10"
                            : "border-border hover:border-primary/30 hover:bg-white/[0.02]"
                        }`}
                      >
                        <span className="flex items-center gap-3">
                          <span
                            className={`w-8 h-8 rounded-lg flex items-center justify-center text-sm font-semibold shrink-0 ${
                              selected
                                ? "bg-primary text-white"
                                : "bg-white/5 text-text-muted"
                            }`}
                          >
                            {opt}
                          </span>
                          <span className="text-sm">{val}</span>
                        </span>
                      </motion.button>
                    );
                  })}
                </div>

                {/* Navigation */}
                <div className="flex items-center justify-between mt-8">
                  <button
                    onClick={() => setCurrentQ((c) => Math.max(0, c - 1))}
                    disabled={currentQ === 0}
                    className="flex items-center gap-2 px-4 py-2.5 rounded-xl border border-border hover:border-primary/30 text-sm disabled:opacity-30 transition-all"
                  >
                    <ChevronLeft className="w-4 h-4" />
                    Previous
                  </button>

                  <div className="flex items-center gap-2">
                    <button
                      onClick={() =>
                        setCurrentQ((c) =>
                          Math.min(questions.length - 1, c + 1)
                        )
                      }
                      className="flex items-center gap-2 px-3 py-2.5 rounded-xl border border-border hover:border-primary/30 text-sm transition-all"
                      title="Skip"
                    >
                      <SkipForward className="w-4 h-4" />
                    </button>

                    {currentQ === questions.length - 1 ? (
                      <button
                        onClick={handleSubmit}
                        disabled={submitting}
                        className="flex items-center gap-2 px-6 py-2.5 rounded-xl bg-gradient-to-r from-primary to-primary-hover text-white font-semibold text-sm hover:shadow-lg hover:shadow-primary/25 transition-all disabled:opacity-50"
                      >
                        {submitting ? (
                          <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                        ) : (
                          <>
                            <Send className="w-4 h-4" />
                            Submit
                          </>
                        )}
                      </button>
                    ) : (
                      <button
                        onClick={() =>
                          setCurrentQ((c) =>
                            Math.min(questions.length - 1, c + 1)
                          )
                        }
                        className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-primary/10 text-primary font-medium text-sm hover:bg-primary/20 transition-all"
                      >
                        Next
                        <ChevronRight className="w-4 h-4" />
                      </button>
                    )}
                  </div>
                </div>
              </motion.div>
            </AnimatePresence>
          </div>

          {/* Question Palette (desktop) */}
          <div className="hidden md:block w-56 shrink-0">
            <div className="rounded-2xl bg-card border border-border p-4 sticky top-24">
              <h3 className="text-sm font-semibold mb-3">Questions</h3>
              <div className="grid grid-cols-5 gap-2">
                {questions.map((question, i) => {
                  const answered = !!answers[question.id.toString()];
                  const isFlagged = flagged.has(i);
                  const isCurrent = i === currentQ;
                  return (
                    <button
                      key={i}
                      onClick={() => setCurrentQ(i)}
                      className={`w-8 h-8 rounded-lg text-xs font-semibold flex items-center justify-center transition-all ${
                        isCurrent
                          ? "bg-primary text-white ring-2 ring-primary/30"
                          : answered
                          ? "bg-success/20 text-success"
                          : isFlagged
                          ? "bg-accent/20 text-accent"
                          : "bg-white/5 text-text-muted hover:bg-white/10"
                      }`}
                    >
                      {i + 1}
                    </button>
                  );
                })}
              </div>
              <div className="mt-4 space-y-2 text-xs text-text-muted">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-success/20" />
                  Answered ({Object.keys(answers).length})
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-accent/20" />
                  Flagged ({flagged.size})
                </div>
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded bg-white/5" />
                  Unanswered (
                  {questions.length - Object.keys(answers).length})
                </div>
              </div>

              <button
                onClick={handleSubmit}
                disabled={submitting}
                className="w-full mt-4 flex items-center justify-center gap-2 py-2.5 rounded-xl bg-gradient-to-r from-primary to-primary-hover text-white font-semibold text-sm hover:shadow-lg hover:shadow-primary/25 transition-all disabled:opacity-50"
              >
                <Send className="w-4 h-4" />
                Submit Quiz
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Palette */}
        {showPalette && (
          <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-end md:hidden">
            <motion.div
              initial={{ y: "100%" }}
              animate={{ y: 0 }}
              className="w-full rounded-t-2xl bg-card border-t border-border p-6"
            >
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-semibold">Question Palette</h3>
                <button
                  onClick={() => setShowPalette(false)}
                  className="text-sm text-text-secondary"
                >
                  Close
                </button>
              </div>
              <div className="grid grid-cols-8 gap-2">
                {questions.map((question, i) => {
                  const answered = !!answers[question.id.toString()];
                  const isCurrent = i === currentQ;
                  return (
                    <button
                      key={i}
                      onClick={() => {
                        setCurrentQ(i);
                        setShowPalette(false);
                      }}
                      className={`w-9 h-9 rounded-lg text-xs font-semibold flex items-center justify-center ${
                        isCurrent
                          ? "bg-primary text-white"
                          : answered
                          ? "bg-success/20 text-success"
                          : "bg-white/5 text-text-muted"
                      }`}
                    >
                      {i + 1}
                    </button>
                  );
                })}
              </div>
            </motion.div>
          </div>
        )}
      </div>
    </div>
  );
}

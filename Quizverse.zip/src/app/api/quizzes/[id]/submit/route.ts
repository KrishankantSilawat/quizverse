import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { quizzes, questions, results, leaderboard } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq, sql } from "drizzle-orm";

export async function POST(
  req: NextRequest,
  { params }: { params: Promise<{ id: string }> }
) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const { id } = await params;
    const quizId = parseInt(id);
    const { answers, timeTaken } = await req.json();
    // answers: { [questionId]: "A"|"B"|"C"|"D" | null }

    const quizQuestions = await db
      .select()
      .from(questions)
      .where(eq(questions.quizId, quizId))
      .orderBy(questions.orderIndex);

    if (quizQuestions.length === 0) {
      return NextResponse.json(
        { error: "No questions found" },
        { status: 400 }
      );
    }

    let score = 0;
    let totalMarks = 0;
    let correctAnswers = 0;
    let wrongAnswers = 0;
    let skipped = 0;

    const answerDetails: {
      questionId: number;
      selected: string | null;
      correct: string;
      isCorrect: boolean;
    }[] = [];

    for (const q of quizQuestions) {
      totalMarks += q.marks || 1;
      const userAnswer = answers[q.id.toString()] || null;

      if (!userAnswer) {
        skipped++;
        answerDetails.push({
          questionId: q.id,
          selected: null,
          correct: q.correctAnswer,
          isCorrect: false,
        });
      } else if (userAnswer === q.correctAnswer) {
        correctAnswers++;
        score += q.marks || 1;
        answerDetails.push({
          questionId: q.id,
          selected: userAnswer,
          correct: q.correctAnswer,
          isCorrect: true,
        });
      } else {
        wrongAnswers++;
        score -= q.negativeMark || 0;
        answerDetails.push({
          questionId: q.id,
          selected: userAnswer,
          correct: q.correctAnswer,
          isCorrect: false,
        });
      }
    }

    if (score < 0) score = 0;
    const percentage = totalMarks > 0 ? (score / totalMarks) * 100 : 0;
    const passed = percentage >= 40;

    const [result] = await db
      .insert(results)
      .values({
        userId: user.id,
        quizId,
        score,
        totalMarks,
        correctAnswers,
        wrongAnswers,
        skipped,
        timeTaken: timeTaken || 0,
        percentage,
        passed,
        answers: answerDetails,
      })
      .returning();

    // Update quiz attempts
    await db
      .update(quizzes)
      .set({ attempts: sql`${quizzes.attempts} + 1` })
      .where(eq(quizzes.id, quizId));

    // Update leaderboard
    const [existingLb] = await db
      .select()
      .from(leaderboard)
      .where(eq(leaderboard.userId, user.id))
      .limit(1);

    if (existingLb) {
      const newTotal = existingLb.totalScore + score;
      const newPlayed = existingLb.quizzesPlayed + 1;
      const newAccuracy =
        ((existingLb.accuracy * existingLb.quizzesPlayed + percentage) /
          newPlayed);
      await db
        .update(leaderboard)
        .set({
          totalScore: newTotal,
          quizzesPlayed: newPlayed,
          accuracy: newAccuracy,
          updatedAt: new Date(),
        })
        .where(eq(leaderboard.userId, user.id));
    } else {
      await db.insert(leaderboard).values({
        userId: user.id,
        totalScore: score,
        quizzesPlayed: 1,
        accuracy: percentage,
      });
    }

    return NextResponse.json({ result });
  } catch (error) {
    console.error("Submit quiz error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

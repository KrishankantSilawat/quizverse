"use client";

import { useState, useEffect, use } from "react";
import Link from "next/link";
import { motion } from "framer-motion";
import {
  Trophy,
  Clock,
  Target,
  CheckCircle2,
  XCircle,
  SkipForward,
  ArrowLeft,
  RefreshCw,
  Home,
  Share2,
  ChevronDown,
  ChevronUp,
  Award,
} from "lucide-react";

interface ResultData {
  id: number;
  score: number;
  totalMarks: number;
  correctAnswers: number;
  wrongAnswers: number;
  skipped: number;
  timeTaken: number;
  percentage: number;
  passed: boolean;
  answers: { questionId: number; selected: string | null; correct: string; isCorrect: boolean }[];
  quizId: number | null;
  quizTitle: string | null;
}

interface QuestionData {
  id: number;
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  correctAnswer: string;
  explanation: string | null;
}

export default function ResultPage({
  params,
}: {
  params: Promise<{ id: string }>;
}) {
  const { id } = use(params);
  const [result, setResult] = useState<ResultData | null>(null);
  const [questions, setQuestions] = useState<QuestionData[]>([]);
  const [showReview, setShowReview] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch(`/api/results/${id}`)
      .then((r) => r.json())
      .then((d) => {
        setResult(d.result);
        setQuestions(d.questions || []);
      })
      .catch(() => {})
      .finally(() => setLoading(false));
  }, [id]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="w-8 h-8 border-2 border-primary border-t-transparent rounded-full animate-spin" />
      </div>
    );
  }

  if (!result) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <p className="text-text-secondary">Result not found</p>
      </div>
    );
  }

  const answersArr = Array.isArray(result.answers) ? result.answers : [];
  const minutes = Math.floor(result.timeTaken / 60);
  const seconds = result.timeTaken % 60;
  const circumference = 2 * Math.PI * 60;
  const dashOffset = circumference - (result.percentage / 100) * circumference;

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-3xl mx-auto">
        <Link
          href="/explore"
          className="inline-flex items-center gap-2 text-text-secondary hover:text-white mb-6 transition-colors"
        >
          <ArrowLeft className="w-4 h-4" />
          Back
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          {/* Header */}
          <div className="text-center mb-8">
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ type: "spring", duration: 0.6, delay: 0.2 }}
              className="inline-block mb-4"
            >
              {result.passed ? (
                <div className="w-20 h-20 rounded-full bg-success/10 border-2 border-success/30 flex items-center justify-center">
                  <Trophy className="w-10 h-10 text-success" />
                </div>
              ) : (
                <div className="w-20 h-20 rounded-full bg-danger/10 border-2 border-danger/30 flex items-center justify-center">
                  <Award className="w-10 h-10 text-danger" />
                </div>
              )}
            </motion.div>

            <h1 className="text-3xl font-bold mb-2">
              {result.passed ? "Congratulations! 🎉" : "Keep Trying! 💪"}
            </h1>
            <p className="text-text-secondary">
              {result.quizTitle || "Quiz"} — {result.passed ? "Passed" : "Failed"}
            </p>
          </div>

          {/* Score Circle & Stats */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
            {/* Circular Progress */}
            <div className="rounded-2xl bg-card border border-border p-8 flex flex-col items-center justify-center">
              <div className="relative w-36 h-36 mb-4">
                <svg className="w-full h-full -rotate-90" viewBox="0 0 128 128">
                  <circle
                    cx="64"
                    cy="64"
                    r="60"
                    fill="none"
                    stroke="rgba(255,255,255,0.05)"
                    strokeWidth="8"
                  />
                  <motion.circle
                    cx="64"
                    cy="64"
                    r="60"
                    fill="none"
                    stroke={result.passed ? "#22c55e" : "#ef4444"}
                    strokeWidth="8"
                    strokeLinecap="round"
                    strokeDasharray={circumference}
                    initial={{ strokeDashoffset: circumference }}
                    animate={{ strokeDashoffset: dashOffset }}
                    transition={{ duration: 1.5, ease: "easeOut", delay: 0.3 }}
                  />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                  <span className="text-3xl font-bold">
                    {result.percentage.toFixed(0)}%
                  </span>
                  <span className="text-xs text-text-muted">Score</span>
                </div>
              </div>
              <p className="text-lg font-semibold">
                {result.score} / {result.totalMarks}
              </p>
            </div>

            {/* Stats Grid */}
            <div className="grid grid-cols-2 gap-3">
              <div className="rounded-xl bg-card border border-border p-4 flex flex-col items-center">
                <CheckCircle2 className="w-6 h-6 text-success mb-2" />
                <span className="text-xl font-bold">{result.correctAnswers}</span>
                <span className="text-xs text-text-muted">Correct</span>
              </div>
              <div className="rounded-xl bg-card border border-border p-4 flex flex-col items-center">
                <XCircle className="w-6 h-6 text-danger mb-2" />
                <span className="text-xl font-bold">{result.wrongAnswers}</span>
                <span className="text-xs text-text-muted">Wrong</span>
              </div>
              <div className="rounded-xl bg-card border border-border p-4 flex flex-col items-center">
                <SkipForward className="w-6 h-6 text-accent mb-2" />
                <span className="text-xl font-bold">{result.skipped}</span>
                <span className="text-xs text-text-muted">Skipped</span>
              </div>
              <div className="rounded-xl bg-card border border-border p-4 flex flex-col items-center">
                <Clock className="w-6 h-6 text-primary mb-2" />
                <span className="text-xl font-bold">
                  {minutes}:{seconds.toString().padStart(2, "0")}
                </span>
                <span className="text-xs text-text-muted">Time</span>
              </div>
              <div className="col-span-2 rounded-xl bg-card border border-border p-4 flex flex-col items-center">
                <Target className="w-6 h-6 text-secondary mb-2" />
                <span className="text-xl font-bold">
                  {result.correctAnswers + result.wrongAnswers > 0
                    ? (
                        (result.correctAnswers /
                          (result.correctAnswers + result.wrongAnswers)) *
                        100
                      ).toFixed(0)
                    : 0}
                  %
                </span>
                <span className="text-xs text-text-muted">Accuracy</span>
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3 mb-8">
            <button
              onClick={() => setShowReview(!showReview)}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border border-border hover:border-primary/30 text-sm font-medium transition-all"
            >
              {showReview ? (
                <ChevronUp className="w-4 h-4" />
              ) : (
                <ChevronDown className="w-4 h-4" />
              )}
              Review Answers
            </button>
            {result.quizId && (
              <Link
                href={`/quiz/${result.quizId}/play`}
                className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-primary/10 text-primary text-sm font-medium hover:bg-primary/20 transition-all"
              >
                <RefreshCw className="w-4 h-4" />
                Retake Quiz
              </Link>
            )}
            <button
              onClick={() => {
                if (typeof navigator !== "undefined" && navigator.share) {
                  navigator.share({
                    title: "QuizVerse Result",
                    text: `I scored ${result.percentage.toFixed(0)}% on ${result.quizTitle}!`,
                    url: window.location.href,
                  });
                }
              }}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border border-border hover:border-primary/30 text-sm font-medium transition-all"
            >
              <Share2 className="w-4 h-4" />
              Share
            </button>
            <Link
              href="/"
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-primary to-primary-hover text-white text-sm font-semibold hover:shadow-lg hover:shadow-primary/25 transition-all"
            >
              <Home className="w-4 h-4" />
              Home
            </Link>
          </div>

          {/* Answer Review */}
          {showReview && (
            <motion.div
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: "auto" }}
              className="space-y-4"
            >
              {questions.map((q, i) => {
                const answer = answersArr.find(
                  (a) => a.questionId === q.id
                );
                const userAnswer = answer?.selected;
                const isCorrect = answer?.isCorrect;

                return (
                  <div
                    key={q.id}
                    className={`rounded-2xl border p-5 ${
                      isCorrect
                        ? "bg-success/5 border-success/20"
                        : userAnswer
                        ? "bg-danger/5 border-danger/20"
                        : "bg-card border-border"
                    }`}
                  >
                    <p className="font-medium mb-3">
                      {i + 1}. {q.question}
                    </p>
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 mb-3">
                      {(["A", "B", "C", "D"] as const).map((opt) => {
                        const val = q[`option${opt}` as keyof QuestionData] as string;
                        if (!val) return null;
                        const isCorrectOpt = q.correctAnswer === opt;
                        const isUserOpt = userAnswer === opt;
                        return (
                          <div
                            key={opt}
                            className={`px-3 py-2 rounded-lg text-sm flex items-center gap-2 ${
                              isCorrectOpt
                                ? "bg-success/10 border border-success/30 text-success"
                                : isUserOpt
                                ? "bg-danger/10 border border-danger/30 text-danger"
                                : "bg-white/5 border border-border"
                            }`}
                          >
                            {isCorrectOpt && (
                              <CheckCircle2 className="w-4 h-4 shrink-0" />
                            )}
                            {isUserOpt && !isCorrectOpt && (
                              <XCircle className="w-4 h-4 shrink-0" />
                            )}
                            {opt}. {val}
                          </div>
                        );
                      })}
                    </div>
                    {q.explanation && (
                      <p className="text-sm text-text-secondary bg-white/5 rounded-lg p-3">
                        💡 {q.explanation}
                      </p>
                    )}
                  </div>
                );
              })}
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

# QuizVerse - Deployment Guide

## 🚀 Deploy to Vercel (FREE - Recommended)

### Step 1: Create Accounts
1. Go to https://vercel.com and sign up (free)
2. Go to https://neon.tech and sign up (free PostgreSQL database)

### Step 2: Create Database on Neon
1. Create a new project on Neon
2. Copy the connection string (looks like: postgresql://user:pass@host/db?sslmode=require)

### Step 3: Deploy to Vercel
1. Push this code to GitHub
2. Go to vercel.com → New Project → Import from GitHub
3. Add Environment Variable:
   - Name: `DATABASE_URL`
   - Value: (paste your Neon connection string)
   - Name: `JWT_SECRET`
   - Value: `your-super-secret-key-here`
4. Click Deploy!

### Step 4: Setup Database
After deployment, run this in your browser:
- Visit: https://your-app.vercel.app/api/seed
- This will create demo users and quizzes

### 🔑 Login Credentials (after seeding)
- Admin: admin@quizverse.app / admin123
- Demo: demo@quizverse.app / demo123

## 📁 Project Structure
- /src/app - Next.js App Router pages
- /src/components - React components
- /src/db - Database schema (Drizzle ORM)
- /src/lib - Utilities and auth

## 🛠 Tech Stack
- Next.js 16 (App Router)
- TypeScript
- Tailwind CSS 4
- Framer Motion
- PostgreSQL + Drizzle ORM
- JWT Authentication

import { NextRequest, NextResponse } from "next/server";
import { db } from "@/db";
import { quizzes, questions, users, categories } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq, desc, ilike, and, sql, count } from "drizzle-orm";

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url);
    const search = searchParams.get("search") || "";
    const category = searchParams.get("category") || "";
    const difficulty = searchParams.get("difficulty") || "";
    const sort = searchParams.get("sort") || "newest";
    const page = parseInt(searchParams.get("page") || "1");
    const limit = parseInt(searchParams.get("limit") || "12");
    const offset = (page - 1) * limit;

    const conditions = [eq(quizzes.published, true)];

    if (search) {
      conditions.push(ilike(quizzes.title, `%${search}%`));
    }

    if (difficulty) {
      conditions.push(eq(quizzes.difficulty, difficulty));
    }

    if (category) {
      const catNum = parseInt(category);
      if (!isNaN(catNum)) {
        conditions.push(eq(quizzes.categoryId, catNum));
      }
    }

    const whereClause = conditions.length > 1 ? and(...conditions) : conditions[0];

    const orderBy =
      sort === "popular"
        ? desc(quizzes.attempts)
        : sort === "rating"
        ? desc(quizzes.rating)
        : desc(quizzes.createdAt);

    const quizList = await db
      .select({
        id: quizzes.id,
        title: quizzes.title,
        description: quizzes.description,
        difficulty: quizzes.difficulty,
        timeLimit: quizzes.timeLimit,
        coverImage: quizzes.coverImage,
        attempts: quizzes.attempts,
        rating: quizzes.rating,
        createdAt: quizzes.createdAt,
        creatorName: users.username,
        categoryName: categories.name,
        categoryId: quizzes.categoryId,
      })
      .from(quizzes)
      .leftJoin(users, eq(quizzes.creatorId, users.id))
      .leftJoin(categories, eq(quizzes.categoryId, categories.id))
      .where(whereClause)
      .orderBy(orderBy)
      .limit(limit)
      .offset(offset);

    // Get question counts
    const quizIds = quizList.map((q) => q.id);
    let questionCounts: Record<number, number> = {};
    if (quizIds.length > 0) {
      const counts = await db
        .select({
          quizId: questions.quizId,
          count: count(),
        })
        .from(questions)
        .where(sql`${questions.quizId} IN (${sql.join(quizIds.map(id => sql`${id}`), sql`, `)})`)
        .groupBy(questions.quizId);
      questionCounts = Object.fromEntries(
        counts.map((c) => [c.quizId, Number(c.count)])
      );
    }

    const enriched = quizList.map((q) => ({
      ...q,
      questionCount: questionCounts[q.id] || 0,
    }));

    // Total count for pagination
    const [totalResult] = await db
      .select({ total: count() })
      .from(quizzes)
      .where(whereClause);

    return NextResponse.json({
      quizzes: enriched,
      total: Number(totalResult.total),
      page,
      totalPages: Math.ceil(Number(totalResult.total) / limit),
    });
  } catch (error) {
    console.error("Get quizzes error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

export async function POST(req: NextRequest) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    const body = await req.json();
    const {
      title,
      description,
      categoryId,
      difficulty,
      timeLimit,
      coverImage,
      published,
      questionList,
    } = body;

    if (!title) {
      return NextResponse.json(
        { error: "Title is required" },
        { status: 400 }
      );
    }

    const [quiz] = await db
      .insert(quizzes)
      .values({
        title,
        description: description || "",
        categoryId: categoryId || null,
        difficulty: difficulty || "medium",
        timeLimit: timeLimit || 600,
        coverImage: coverImage || "",
        published: published || false,
        creatorId: user.id,
      })
      .returning();

    // Insert questions
    if (questionList && questionList.length > 0) {
      const qValues = questionList.map(
        (
          q: {
            question: string;
            optionA: string;
            optionB: string;
            optionC: string;
            optionD: string;
            correctAnswer: string;
            explanation: string;
            marks: number;
            negativeMark: number;
          },
          i: number
        ) => ({
          quizId: quiz.id,
          question: q.question,
          optionA: q.optionA,
          optionB: q.optionB,
          optionC: q.optionC || "",
          optionD: q.optionD || "",
          correctAnswer: q.correctAnswer,
          explanation: q.explanation || "",
          marks: q.marks || 1,
          negativeMark: q.negativeMark || 0,
          orderIndex: i,
        })
      );
      await db.insert(questions).values(qValues);
    }

    return NextResponse.json({ quiz }, { status: 201 });
  } catch (error) {
    console.error("Create quiz error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

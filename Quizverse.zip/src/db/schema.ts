import {
  pgTable,
  text,
  varchar,
  integer,
  boolean,
  timestamp,
  jsonb,
  serial,
  real,
} from "drizzle-orm/pg-core";

/* ── Users ──────────────────────────────────────────── */
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: varchar("username", { length: 100 }).notNull().unique(),
  email: varchar("email", { length: 255 }).notNull().unique(),
  password: text("password").notNull(),
  bio: text("bio").default(""),
  avatar: text("avatar").default(""),
  role: varchar("role", { length: 20 }).default("user").notNull(),
  banned: boolean("banned").default(false).notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/* ── Categories ─────────────────────────────────────── */
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: varchar("name", { length: 100 }).notNull().unique(),
  icon: varchar("icon", { length: 50 }).default("BookOpen"),
  color: varchar("color", { length: 20 }).default("#6C63FF"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ── Quizzes ────────────────────────────────────────── */
export const quizzes = pgTable("quizzes", {
  id: serial("id").primaryKey(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description").default(""),
  categoryId: integer("category_id").references(() => categories.id),
  difficulty: varchar("difficulty", { length: 20 }).default("medium"),
  timeLimit: integer("time_limit").default(600), // seconds
  coverImage: text("cover_image").default(""),
  published: boolean("published").default(false).notNull(),
  creatorId: integer("creator_id")
    .references(() => users.id)
    .notNull(),
  attempts: integer("attempts").default(0).notNull(),
  rating: real("rating").default(0),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/* ── Questions ──────────────────────────────────────── */
export const questions = pgTable("questions", {
  id: serial("id").primaryKey(),
  quizId: integer("quiz_id")
    .references(() => quizzes.id, { onDelete: "cascade" })
    .notNull(),
  question: text("question").notNull(),
  optionA: text("option_a").notNull(),
  optionB: text("option_b").notNull(),
  optionC: text("option_c").default(""),
  optionD: text("option_d").default(""),
  correctAnswer: varchar("correct_answer", { length: 1 }).notNull(), // A/B/C/D
  explanation: text("explanation").default(""),
  marks: integer("marks").default(1),
  negativeMark: real("negative_mark").default(0),
  orderIndex: integer("order_index").default(0),
});

/* ── Results ────────────────────────────────────────── */
export const results = pgTable("results", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .references(() => users.id)
    .notNull(),
  quizId: integer("quiz_id")
    .references(() => quizzes.id)
    .notNull(),
  score: integer("score").default(0).notNull(),
  totalMarks: integer("total_marks").default(0).notNull(),
  correctAnswers: integer("correct_answers").default(0).notNull(),
  wrongAnswers: integer("wrong_answers").default(0).notNull(),
  skipped: integer("skipped").default(0).notNull(),
  timeTaken: integer("time_taken").default(0).notNull(), // seconds
  percentage: real("percentage").default(0).notNull(),
  passed: boolean("passed").default(false).notNull(),
  answers: jsonb("answers").default("[]"), // [{questionId, selected, correct}]
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

/* ── Leaderboard ────────────────────────────────────── */
export const leaderboard = pgTable("leaderboard", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .references(() => users.id)
    .notNull(),
  totalScore: integer("total_score").default(0).notNull(),
  quizzesPlayed: integer("quizzes_played").default(0).notNull(),
  accuracy: real("accuracy").default(0).notNull(),
  updatedAt: timestamp("updated_at").defaultNow().notNull(),
});

/* ── Favorites ──────────────────────────────────────── */
export const favorites = pgTable("favorites", {
  id: serial("id").primaryKey(),
  userId: integer("user_id")
    .references(() => users.id)
    .notNull(),
  quizId: integer("quiz_id")
    .references(() => quizzes.id)
    .notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

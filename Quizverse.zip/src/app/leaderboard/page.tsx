"use client";

import { useState, useEffect } from "react";
import { motion } from "framer-motion";
import { Trophy, Medal, Target, User, Gamepad2 } from "lucide-react";

interface Leader {
  id: number;
  totalScore: number;
  quizzesPlayed: number;
  accuracy: number;
  username: string | null;
  avatar: string | null;
  userId: number | null;
}

export default function LeaderboardPage() {
  const [leaders, setLeaders] = useState<Leader[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    fetch("/api/leaderboard")
      .then((r) => r.json())
      .then((d) => setLeaders(d.leaderboard || []))
      .catch(() => {})
      .finally(() => setLoading(false));
  }, []);

  const getMedalColor = (rank: number) => {
    if (rank === 0) return "text-yellow-400";
    if (rank === 1) return "text-gray-300";
    if (rank === 2) return "text-amber-600";
    return "text-text-muted";
  };

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-10"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-2xl bg-accent/10 mb-4">
            <Trophy className="w-8 h-8 text-accent" />
          </div>
          <h1 className="text-3xl sm:text-4xl font-bold mb-3">
            <span className="gradient-text">Leaderboard</span>
          </h1>
          <p className="text-text-secondary">
            Top quiz champions ranked by total score
          </p>
        </motion.div>

        {/* Top 3 Podium */}
        {leaders.length >= 3 && (
          <div className="flex items-end justify-center gap-4 mb-10">
            {[1, 0, 2].map((idx) => {
              const leader = leaders[idx];
              const isFirst = idx === 0;
              return (
                <motion.div
                  key={idx}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: idx * 0.15 }}
                  className={`flex flex-col items-center ${
                    isFirst ? "order-2" : idx === 1 ? "order-1" : "order-3"
                  }`}
                >
                  <div
                    className={`w-16 h-16 sm:w-20 sm:h-20 rounded-full bg-gradient-to-br ${
                      isFirst
                        ? "from-yellow-400 to-orange-500"
                        : idx === 1
                        ? "from-gray-300 to-gray-500"
                        : "from-amber-600 to-amber-800"
                    } flex items-center justify-center mb-2 ${
                      isFirst ? "ring-4 ring-yellow-400/30" : ""
                    }`}
                  >
                    <User className="w-8 h-8 sm:w-10 sm:h-10 text-white" />
                  </div>
                  <p className="font-semibold text-sm mb-1">
                    {leader.username || "User"}
                  </p>
                  <p className="text-xs text-text-muted mb-2">
                    {leader.totalScore} pts
                  </p>
                  <div
                    className={`w-20 sm:w-24 rounded-t-xl flex items-center justify-center py-3 ${
                      isFirst
                        ? "bg-yellow-400/10 h-24"
                        : idx === 1
                        ? "bg-gray-400/10 h-16"
                        : "bg-amber-600/10 h-12"
                    }`}
                  >
                    <span className="text-2xl font-bold">
                      {idx + 1}
                    </span>
                  </div>
                </motion.div>
              );
            })}
          </div>
        )}

        {/* Leaderboard Table */}
        {loading ? (
          <div className="space-y-3">
            {Array.from({ length: 5 }).map((_, i) => (
              <div
                key={i}
                className="skeleton h-16 rounded-xl"
              />
            ))}
          </div>
        ) : leaders.length === 0 ? (
          <div className="text-center py-16">
            <Gamepad2 className="w-16 h-16 text-text-muted mx-auto mb-4" />
            <h3 className="text-xl font-semibold mb-2">No rankings yet</h3>
            <p className="text-text-secondary">
              Be the first to play a quiz and claim the top spot!
            </p>
          </div>
        ) : (
          <div className="space-y-2">
            {leaders.map((leader, i) => (
              <motion.div
                key={leader.id}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: i * 0.05 }}
                className={`flex items-center gap-4 p-4 rounded-xl border transition-all hover:bg-white/[0.02] ${
                  i < 3
                    ? "bg-card border-primary/10"
                    : "bg-card border-border"
                }`}
              >
                <span
                  className={`w-8 text-center font-bold text-lg ${getMedalColor(
                    i
                  )}`}
                >
                  {i < 3 ? (
                    <Medal className="w-6 h-6 mx-auto" />
                  ) : (
                    i + 1
                  )}
                </span>

                <div className="w-10 h-10 rounded-full bg-primary/10 flex items-center justify-center shrink-0">
                  <User className="w-5 h-5 text-primary" />
                </div>

                <div className="flex-1 min-w-0">
                  <p className="font-medium truncate">
                    {leader.username || "Anonymous"}
                  </p>
                  <p className="text-xs text-text-muted">
                    {leader.quizzesPlayed} quizzes played
                  </p>
                </div>

                <div className="flex items-center gap-6 text-sm">
                  <div className="text-center hidden sm:block">
                    <p className="text-text-muted text-xs">Accuracy</p>
                    <p className="font-semibold flex items-center gap-1">
                      <Target className="w-3.5 h-3.5 text-secondary" />
                      {leader.accuracy.toFixed(0)}%
                    </p>
                  </div>
                  <div className="text-right">
                    <p className="text-text-muted text-xs">Score</p>
                    <p className="font-bold text-primary">
                      {leader.totalScore}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

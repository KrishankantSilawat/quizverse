"use client";

import { useState, useEffect } from "react";
import { useRouter } from "next/navigation";
import { motion } from "framer-motion";
import {
  PlusCircle,
  Trash2,
  Copy,
  Save,
  Send,
  Eye,
  ChevronDown,
  ChevronUp,
  GripVertical,
  AlertCircle,
} from "lucide-react";

interface QuestionItem {
  id: string;
  question: string;
  optionA: string;
  optionB: string;
  optionC: string;
  optionD: string;
  correctAnswer: string;
  explanation: string;
  marks: number;
  negativeMark: number;
}

interface Category {
  id: number;
  name: string;
}

const emptyQuestion = (): QuestionItem => ({
  id: Math.random().toString(36).slice(2),
  question: "",
  optionA: "",
  optionB: "",
  optionC: "",
  optionD: "",
  correctAnswer: "A",
  explanation: "",
  marks: 1,
  negativeMark: 0,
});

export default function CreateQuizPage() {
  const router = useRouter();
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [categoryId, setCategoryId] = useState("");
  const [difficulty, setDifficulty] = useState("medium");
  const [timeLimit, setTimeLimit] = useState(10);
  const [questionList, setQuestionList] = useState<QuestionItem[]>([emptyQuestion()]);
  const [expandedQ, setExpandedQ] = useState<string | null>(null);
  const [categories, setCategories] = useState<Category[]>([]);
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPreview, setShowPreview] = useState(false);

  useEffect(() => {
    fetch("/api/categories")
      .then((r) => r.json())
      .then((d) => setCategories(d.categories || []))
      .catch(() => {});
    setExpandedQ(questionList[0]?.id || null);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const addQuestion = () => {
    const q = emptyQuestion();
    setQuestionList([...questionList, q]);
    setExpandedQ(q.id);
  };

  const removeQuestion = (id: string) => {
    if (questionList.length <= 1) return;
    setQuestionList(questionList.filter((q) => q.id !== id));
  };

  const duplicateQuestion = (q: QuestionItem) => {
    const dup = { ...q, id: Math.random().toString(36).slice(2) };
    setQuestionList([...questionList, dup]);
    setExpandedQ(dup.id);
  };

  const updateQuestion = (id: string, field: string, value: string | number) => {
    setQuestionList(
      questionList.map((q) => (q.id === id ? { ...q, [field]: value } : q))
    );
  };

  const handleSubmit = async (publish: boolean) => {
    setError("");
    if (!title.trim()) {
      setError("Quiz title is required");
      return;
    }
    if (questionList.length === 0) {
      setError("Add at least one question");
      return;
    }
    for (let i = 0; i < questionList.length; i++) {
      const q = questionList[i];
      if (!q.question.trim() || !q.optionA.trim() || !q.optionB.trim()) {
        setError(`Question ${i + 1} is incomplete`);
        return;
      }
    }

    setLoading(true);
    try {
      const res = await fetch("/api/quizzes", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          title,
          description,
          categoryId: categoryId ? parseInt(categoryId) : null,
          difficulty,
          timeLimit: timeLimit * 60,
          published: publish,
          questionList,
        }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Failed to create quiz");
        return;
      }
      router.push(publish ? `/quiz/${data.quiz.id}` : "/dashboard");
    } catch {
      setError("Something went wrong");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen px-4 py-8">
      <div className="max-w-4xl mx-auto">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <h1 className="text-3xl font-bold mb-2">
            Create <span className="gradient-text">Quiz</span>
          </h1>
          <p className="text-text-secondary mb-8">
            Build an engaging quiz for your audience
          </p>

          {error && (
            <div className="mb-6 p-4 rounded-xl bg-danger/10 border border-danger/20 text-danger text-sm flex items-center gap-2">
              <AlertCircle className="w-5 h-5 shrink-0" />
              {error}
            </div>
          )}

          {/* Quiz Details */}
          <div className="p-6 rounded-2xl bg-card border border-border mb-6 space-y-5">
            <h2 className="font-semibold text-lg">Quiz Details</h2>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-2">
                Title *
              </label>
              <input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Enter quiz title"
                className="w-full px-4 py-3 rounded-xl bg-bg border border-border focus:border-primary outline-none text-white placeholder-text-muted text-sm transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-text-secondary mb-2">
                Description
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe your quiz"
                rows={3}
                className="w-full px-4 py-3 rounded-xl bg-bg border border-border focus:border-primary outline-none text-white placeholder-text-muted text-sm transition-all resize-none"
              />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">
                  Category
                </label>
                <select
                  value={categoryId}
                  onChange={(e) => setCategoryId(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-bg border border-border focus:border-primary outline-none text-white text-sm appearance-none cursor-pointer"
                >
                  <option value="">Select category</option>
                  {categories.map((c) => (
                    <option key={c.id} value={c.id}>
                      {c.name}
                    </option>
                  ))}
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">
                  Difficulty
                </label>
                <select
                  value={difficulty}
                  onChange={(e) => setDifficulty(e.target.value)}
                  className="w-full px-4 py-3 rounded-xl bg-bg border border-border focus:border-primary outline-none text-white text-sm appearance-none cursor-pointer"
                >
                  <option value="easy">Easy</option>
                  <option value="medium">Medium</option>
                  <option value="hard">Hard</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-text-secondary mb-2">
                  Time Limit (minutes)
                </label>
                <input
                  type="number"
                  value={timeLimit}
                  onChange={(e) => setTimeLimit(parseInt(e.target.value) || 10)}
                  min={1}
                  className="w-full px-4 py-3 rounded-xl bg-bg border border-border focus:border-primary outline-none text-white text-sm transition-all"
                />
              </div>
            </div>
          </div>

          {/* Questions */}
          <div className="space-y-4 mb-6">
            <div className="flex items-center justify-between">
              <h2 className="font-semibold text-lg">
                Questions ({questionList.length})
              </h2>
              <button
                onClick={() => setShowPreview(!showPreview)}
                className="flex items-center gap-2 px-4 py-2 rounded-xl border border-border hover:border-primary/30 text-sm text-text-secondary hover:text-white transition-all"
              >
                <Eye className="w-4 h-4" />
                Preview
              </button>
            </div>

            {questionList.map((q, idx) => (
              <motion.div
                key={q.id}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="rounded-2xl bg-card border border-border overflow-hidden"
              >
                {/* Question Header */}
                <button
                  onClick={() =>
                    setExpandedQ(expandedQ === q.id ? null : q.id)
                  }
                  className="w-full flex items-center justify-between p-4 hover:bg-white/[0.02] transition-colors"
                >
                  <div className="flex items-center gap-3">
                    <GripVertical className="w-4 h-4 text-text-muted" />
                    <span className="w-8 h-8 rounded-lg bg-primary/10 text-primary text-sm font-semibold flex items-center justify-center">
                      {idx + 1}
                    </span>
                    <span className="text-sm font-medium truncate max-w-xs">
                      {q.question || "New Question"}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        duplicateQuestion(q);
                      }}
                      className="p-1.5 rounded-lg hover:bg-white/5 text-text-muted hover:text-white transition-colors"
                      title="Duplicate"
                    >
                      <Copy className="w-4 h-4" />
                    </button>
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        removeQuestion(q.id);
                      }}
                      className="p-1.5 rounded-lg hover:bg-danger/10 text-text-muted hover:text-danger transition-colors"
                      title="Delete"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                    {expandedQ === q.id ? (
                      <ChevronUp className="w-5 h-5 text-text-muted" />
                    ) : (
                      <ChevronDown className="w-5 h-5 text-text-muted" />
                    )}
                  </div>
                </button>

                {/* Question Body */}
                {expandedQ === q.id && (
                  <motion.div
                    initial={{ height: 0, opacity: 0 }}
                    animate={{ height: "auto", opacity: 1 }}
                    className="px-4 pb-4 space-y-4 border-t border-border pt-4"
                  >
                    <div>
                      <label className="block text-xs font-medium text-text-secondary mb-1.5">
                        Question *
                      </label>
                      <textarea
                        value={q.question}
                        onChange={(e) =>
                          updateQuestion(q.id, "question", e.target.value)
                        }
                        placeholder="Enter your question"
                        rows={2}
                        className="w-full px-4 py-2.5 rounded-xl bg-bg border border-border focus:border-primary outline-none text-white placeholder-text-muted text-sm resize-none"
                      />
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      {(["A", "B", "C", "D"] as const).map((opt) => (
                        <div key={opt}>
                          <label className="block text-xs font-medium text-text-secondary mb-1.5">
                            Option {opt}{" "}
                            {(opt === "A" || opt === "B") && "*"}
                          </label>
                          <input
                            value={
                              q[
                                `option${opt}` as keyof QuestionItem
                              ] as string
                            }
                            onChange={(e) =>
                              updateQuestion(
                                q.id,
                                `option${opt}`,
                                e.target.value
                              )
                            }
                            placeholder={`Option ${opt}`}
                            className={`w-full px-4 py-2.5 rounded-xl bg-bg border focus:border-primary outline-none text-white placeholder-text-muted text-sm transition-all ${
                              q.correctAnswer === opt
                                ? "border-success/50 bg-success/5"
                                : "border-border"
                            }`}
                          />
                        </div>
                      ))}
                    </div>

                    <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                      <div>
                        <label className="block text-xs font-medium text-text-secondary mb-1.5">
                          Correct Answer
                        </label>
                        <select
                          value={q.correctAnswer}
                          onChange={(e) =>
                            updateQuestion(q.id, "correctAnswer", e.target.value)
                          }
                          className="w-full px-4 py-2.5 rounded-xl bg-bg border border-border focus:border-primary outline-none text-white text-sm appearance-none cursor-pointer"
                        >
                          <option value="A">Option A</option>
                          <option value="B">Option B</option>
                          <option value="C">Option C</option>
                          <option value="D">Option D</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-text-secondary mb-1.5">
                          Marks
                        </label>
                        <input
                          type="number"
                          value={q.marks}
                          onChange={(e) =>
                            updateQuestion(
                              q.id,
                              "marks",
                              parseInt(e.target.value) || 1
                            )
                          }
                          min={1}
                          className="w-full px-4 py-2.5 rounded-xl bg-bg border border-border focus:border-primary outline-none text-white text-sm"
                        />
                      </div>
                      <div>
                        <label className="block text-xs font-medium text-text-secondary mb-1.5">
                          Negative Marks
                        </label>
                        <input
                          type="number"
                          value={q.negativeMark}
                          onChange={(e) =>
                            updateQuestion(
                              q.id,
                              "negativeMark",
                              parseFloat(e.target.value) || 0
                            )
                          }
                          min={0}
                          step={0.25}
                          className="w-full px-4 py-2.5 rounded-xl bg-bg border border-border focus:border-primary outline-none text-white text-sm"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="block text-xs font-medium text-text-secondary mb-1.5">
                        Explanation
                      </label>
                      <textarea
                        value={q.explanation}
                        onChange={(e) =>
                          updateQuestion(q.id, "explanation", e.target.value)
                        }
                        placeholder="Explain the answer (optional)"
                        rows={2}
                        className="w-full px-4 py-2.5 rounded-xl bg-bg border border-border focus:border-primary outline-none text-white placeholder-text-muted text-sm resize-none"
                      />
                    </div>
                  </motion.div>
                )}
              </motion.div>
            ))}

            <button
              onClick={addQuestion}
              className="w-full flex items-center justify-center gap-2 p-4 rounded-2xl border-2 border-dashed border-border hover:border-primary/30 text-text-secondary hover:text-primary transition-all"
            >
              <PlusCircle className="w-5 h-5" />
              Add Question
            </button>
          </div>

          {/* Actions */}
          <div className="flex flex-col sm:flex-row gap-3">
            <button
              onClick={() => handleSubmit(false)}
              disabled={loading}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl border border-border hover:border-primary/30 text-white font-medium transition-all disabled:opacity-50"
            >
              <Save className="w-5 h-5" />
              Save Draft
            </button>
            <button
              onClick={() => handleSubmit(true)}
              disabled={loading}
              className="flex-1 flex items-center justify-center gap-2 py-3 rounded-xl bg-gradient-to-r from-primary to-primary-hover text-white font-semibold hover:shadow-lg hover:shadow-primary/25 transition-all disabled:opacity-50"
            >
              {loading ? (
                <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
              ) : (
                <>
                  <Send className="w-5 h-5" />
                  Publish Quiz
                </>
              )}
            </button>
          </div>

          {/* Preview Modal */}
          {showPreview && (
            <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
              <motion.div
                initial={{ opacity: 0, scale: 0.95 }}
                animate={{ opacity: 1, scale: 1 }}
                className="w-full max-w-2xl max-h-[80vh] overflow-y-auto rounded-2xl bg-card border border-border p-6"
              >
                <div className="flex items-center justify-between mb-6">
                  <h2 className="text-xl font-bold">Quiz Preview</h2>
                  <button
                    onClick={() => setShowPreview(false)}
                    className="px-4 py-2 rounded-xl bg-white/5 hover:bg-white/10 text-sm transition-colors"
                  >
                    Close
                  </button>
                </div>

                <h3 className="text-lg font-semibold mb-2">
                  {title || "Untitled Quiz"}
                </h3>
                <p className="text-text-secondary text-sm mb-6">
                  {description || "No description"}
                </p>

                <div className="space-y-4">
                  {questionList.map((q, i) => (
                    <div
                      key={q.id}
                      className="p-4 rounded-xl bg-bg border border-border"
                    >
                      <p className="font-medium mb-3">
                        {i + 1}. {q.question || "Empty question"}
                      </p>
                      <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                        {(["A", "B", "C", "D"] as const).map((opt) => {
                          const val = q[
                            `option${opt}` as keyof QuestionItem
                          ] as string;
                          if (!val) return null;
                          return (
                            <div
                              key={opt}
                              className={`px-3 py-2 rounded-lg text-sm ${
                                q.correctAnswer === opt
                                  ? "bg-success/10 border border-success/30 text-success"
                                  : "bg-white/5 border border-border"
                              }`}
                            >
                              {opt}. {val}
                            </div>
                          );
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              </motion.div>
            </div>
          )}
        </motion.div>
      </div>
    </div>
  );
}

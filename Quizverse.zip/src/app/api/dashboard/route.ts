import { NextResponse } from "next/server";
import { db } from "@/db";
import { quizzes, results, leaderboard } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { eq, count, avg, desc } from "drizzle-orm";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
    }

    // Quizzes created
    const [createdCount] = await db
      .select({ count: count() })
      .from(quizzes)
      .where(eq(quizzes.creatorId, user.id));

    // Quizzes played
    const [playedCount] = await db
      .select({ count: count() })
      .from(results)
      .where(eq(results.userId, user.id));

    // Average score
    const [avgScore] = await db
      .select({ avg: avg(results.percentage) })
      .from(results)
      .where(eq(results.userId, user.id));

    // Recent results
    const recentResults = await db
      .select({
        id: results.id,
        score: results.score,
        totalMarks: results.totalMarks,
        percentage: results.percentage,
        passed: results.passed,
        createdAt: results.createdAt,
        quizTitle: quizzes.title,
      })
      .from(results)
      .leftJoin(quizzes, eq(results.quizId, quizzes.id))
      .where(eq(results.userId, user.id))
      .orderBy(desc(results.createdAt))
      .limit(10);

    // Leaderboard rank
    const [lb] = await db
      .select()
      .from(leaderboard)
      .where(eq(leaderboard.userId, user.id))
      .limit(1);

    return NextResponse.json({
      stats: {
        created: Number(createdCount.count),
        played: Number(playedCount.count),
        avgScore: Number(avgScore.avg || 0).toFixed(1),
        leaderboardScore: lb?.totalScore || 0,
      },
      recentResults,
    });
  } catch (error) {
    console.error("Dashboard error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

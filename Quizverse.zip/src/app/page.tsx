"use client";

import Link from "next/link";
import { motion } from "framer-motion";
import {
  Brain,
  Timer,
  Trophy,
  BarChart3,
  Shield,
  Smartphone,
  Sparkles,
  Zap,
  ArrowRight,
  Star,
  Users,
  BookOpen,
  Code,
  FlaskConical,
  Landmark,
  Dumbbell,
  Clapperboard,
  Globe,
  Cpu,
  Calculator,
  ChevronRight,
} from "lucide-react";
import { useState, useEffect } from "react";

const fadeUp = {
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.6 },
};

const stagger = {
  animate: { transition: { staggerChildren: 0.1 } },
};

const features = [
  { icon: Brain, title: "Quiz Builder", desc: "Intuitive drag-and-drop builder with rich text editing", color: "from-primary to-purple-500" },
  { icon: Timer, title: "Smart Timer", desc: "Configurable countdown timers with auto-submit", color: "from-secondary to-cyan-400" },
  { icon: Trophy, title: "Leaderboard", desc: "Real-time rankings and competitive scoring", color: "from-accent to-orange-400" },
  { icon: Zap, title: "Instant Results", desc: "Get detailed results and analytics immediately", color: "from-success to-emerald-400" },
  { icon: BarChart3, title: "Analytics", desc: "Deep insights into quiz performance and trends", color: "from-blue-500 to-indigo-400" },
  { icon: Smartphone, title: "Responsive", desc: "Perfect experience on desktop, tablet, and mobile", color: "from-pink-500 to-rose-400" },
  { icon: Shield, title: "Secure", desc: "Enterprise-grade security with JWT authentication", color: "from-red-500 to-orange-400" },
  { icon: Sparkles, title: "Dark Theme", desc: "Beautiful glassmorphism dark UI by default", color: "from-violet-500 to-purple-400" },
];

const categoryList = [
  { icon: Code, name: "Programming", color: "#6C63FF" },
  { icon: FlaskConical, name: "Science", color: "#00E5FF" },
  { icon: Landmark, name: "History", color: "#FFB800" },
  { icon: Dumbbell, name: "Sports", color: "#22c55e" },
  { icon: Clapperboard, name: "Movies", color: "#ef4444" },
  { icon: Globe, name: "Geography", color: "#8b5cf6" },
  { icon: Cpu, name: "Technology", color: "#06b6d4" },
  { icon: Calculator, name: "Mathematics", color: "#f59e0b" },
];

export default function HomePage() {
  const [quizzes, setQuizzes] = useState<Array<{
    id: number;
    title: string;
    description: string | null;
    difficulty: string | null;
    categoryName: string | null;
    attempts: number;
    questionCount: number;
    creatorName: string | null;
    timeLimit: number | null;
  }>>([]);

  useEffect(() => {
    fetch("/api/quizzes?limit=6")
      .then((r) => r.json())
      .then((d) => setQuizzes(d.quizzes || []))
      .catch(() => {});
  }, []);

  return (
    <div className="overflow-hidden">
      {/* Hero Section */}
      <section className="relative min-h-[90vh] flex items-center justify-center px-4">
        {/* Background effects */}
        <div className="absolute inset-0 overflow-hidden">
          <div className="absolute top-1/4 left-1/4 w-96 h-96 bg-primary/10 rounded-full blur-[120px]" />
          <div className="absolute bottom-1/4 right-1/4 w-96 h-96 bg-secondary/10 rounded-full blur-[120px]" />
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-64 h-64 bg-accent/5 rounded-full blur-[100px]" />
        </div>

        {/* Grid pattern */}
        <div
          className="absolute inset-0 opacity-[0.03]"
          style={{
            backgroundImage:
              "linear-gradient(rgba(255,255,255,0.1) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,0.1) 1px, transparent 1px)",
            backgroundSize: "60px 60px",
          }}
        />

        <div className="relative max-w-6xl mx-auto text-center">
          <motion.div {...fadeUp} transition={{ duration: 0.6, delay: 0 }}>
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm mb-8">
              <Sparkles className="w-4 h-4" />
              <span>The future of online quizzes</span>
              <ChevronRight className="w-4 h-4" />
            </div>
          </motion.div>

          <motion.h1
            {...fadeUp}
            transition={{ duration: 0.6, delay: 0.1 }}
            className="text-4xl sm:text-5xl md:text-7xl font-bold leading-tight mb-6"
          >
            Create Beautiful{" "}
            <span className="gradient-text">Online Quizzes</span>
            <br />
            in Minutes
          </motion.h1>

          <motion.p
            {...fadeUp}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="text-lg sm:text-xl text-text-secondary max-w-2xl mx-auto mb-10"
          >
            Create quizzes, share them instantly, and analyze results with
            powerful dashboards. Built for educators, teams, and curious minds.
          </motion.p>

          <motion.div
            {...fadeUp}
            transition={{ duration: 0.6, delay: 0.3 }}
            className="flex flex-col sm:flex-row items-center justify-center gap-4"
          >
            <Link
              href="/create"
              className="group flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-primary to-primary-hover text-white font-semibold hover:shadow-xl hover:shadow-primary/25 transition-all duration-300 transform hover:scale-105"
            >
              Create Quiz
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </Link>
            <Link
              href="/explore"
              className="flex items-center gap-2 px-8 py-3.5 rounded-xl border border-border hover:border-primary/50 text-white font-semibold hover:bg-primary/5 transition-all duration-300"
            >
              Explore Quizzes
            </Link>
          </motion.div>

          {/* Stats */}
          <motion.div
            {...fadeUp}
            transition={{ duration: 0.6, delay: 0.4 }}
            className="flex items-center justify-center gap-8 sm:gap-16 mt-16"
          >
            {[
              { value: "1000+", label: "Quizzes", icon: BookOpen },
              { value: "20K+", label: "Users", icon: Users },
              { value: "98%", label: "Satisfaction", icon: Star },
            ].map((stat) => (
              <div key={stat.label} className="text-center">
                <div className="flex items-center justify-center gap-2 mb-1">
                  <stat.icon className="w-5 h-5 text-primary" />
                  <span className="text-2xl sm:text-3xl font-bold gradient-text">
                    {stat.value}
                  </span>
                </div>
                <p className="text-sm text-text-muted">{stat.label}</p>
              </div>
            ))}
          </motion.div>

          {/* Floating elements */}
          <div className="hidden lg:block">
            <div className="absolute top-20 left-10 animate-float">
              <div className="w-14 h-14 rounded-2xl bg-primary/10 border border-primary/20 flex items-center justify-center backdrop-blur-sm">
                <Brain className="w-7 h-7 text-primary" />
              </div>
            </div>
            <div className="absolute top-32 right-16 animate-float-delayed">
              <div className="w-12 h-12 rounded-2xl bg-secondary/10 border border-secondary/20 flex items-center justify-center backdrop-blur-sm">
                <Trophy className="w-6 h-6 text-secondary" />
              </div>
            </div>
            <div className="absolute bottom-20 left-20 animate-float-delayed">
              <div className="w-10 h-10 rounded-xl bg-accent/10 border border-accent/20 flex items-center justify-center backdrop-blur-sm">
                <Zap className="w-5 h-5 text-accent" />
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-20 px-4">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Everything You Need to{" "}
              <span className="gradient-text">Build Quizzes</span>
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              Powerful features packed into a beautiful, intuitive interface
            </p>
          </motion.div>

          <motion.div
            variants={stagger}
            initial="initial"
            whileInView="animate"
            viewport={{ once: true }}
            className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4"
          >
            {features.map((f, i) => (
              <motion.div
                key={i}
                variants={fadeUp}
                className="group p-6 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-xl hover:shadow-primary/5 cursor-default"
              >
                <div
                  className={`w-12 h-12 rounded-xl bg-gradient-to-br ${f.color} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}
                >
                  <f.icon className="w-6 h-6 text-white" />
                </div>
                <h3 className="font-semibold mb-2">{f.title}</h3>
                <p className="text-sm text-text-secondary">{f.desc}</p>
              </motion.div>
            ))}
          </motion.div>
        </div>
      </section>

      {/* Categories Section */}
      <section className="py-20 px-4 bg-card/30">
        <div className="max-w-7xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="text-center mb-16"
          >
            <h2 className="text-3xl sm:text-4xl font-bold mb-4">
              Popular <span className="gradient-text">Categories</span>
            </h2>
            <p className="text-text-secondary max-w-xl mx-auto">
              Explore quizzes across a wide range of topics
            </p>
          </motion.div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            {categoryList.map((cat, i) => (
              <motion.div
                key={cat.name}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.05 }}
              >
                <Link
                  href={`/explore?search=${cat.name}`}
                  className="group flex flex-col items-center gap-3 p-6 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-lg hover:shadow-primary/5"
                >
                  <div
                    className="w-14 h-14 rounded-2xl flex items-center justify-center transition-transform group-hover:scale-110"
                    style={{ backgroundColor: cat.color + "15" }}
                  >
                    <cat.icon
                      className="w-7 h-7"
                      style={{ color: cat.color }}
                    />
                  </div>
                  <span className="font-medium text-sm">{cat.name}</span>
                </Link>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Latest Quizzes */}
      {quizzes.length > 0 && (
        <section className="py-20 px-4">
          <div className="max-w-7xl mx-auto">
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              className="flex items-center justify-between mb-10"
            >
              <div>
                <h2 className="text-3xl font-bold mb-2">Latest Quizzes</h2>
                <p className="text-text-secondary">
                  Jump into a quiz right now
                </p>
              </div>
              <Link
                href="/explore"
                className="hidden sm:flex items-center gap-2 text-primary hover:underline font-medium"
              >
                View All <ArrowRight className="w-4 h-4" />
              </Link>
            </motion.div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {quizzes.map((quiz, i) => (
                <motion.div
                  key={quiz.id}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Link
                    href={`/quiz/${quiz.id}`}
                    className="group block p-6 rounded-2xl bg-card border border-border hover:border-primary/30 transition-all duration-300 hover:shadow-xl hover:shadow-primary/5"
                  >
                    <div className="flex items-start justify-between mb-4">
                      <span className="px-3 py-1 rounded-full text-xs font-medium bg-primary/10 text-primary">
                        {quiz.categoryName || "General"}
                      </span>
                      <span
                        className={`px-3 py-1 rounded-full text-xs font-medium ${
                          quiz.difficulty === "hard"
                            ? "bg-danger/10 text-danger"
                            : quiz.difficulty === "easy"
                            ? "bg-success/10 text-success"
                            : "bg-accent/10 text-accent"
                        }`}
                      >
                        {quiz.difficulty}
                      </span>
                    </div>
                    <h3 className="font-semibold text-lg mb-2 group-hover:text-primary transition-colors">
                      {quiz.title}
                    </h3>
                    <p className="text-sm text-text-secondary line-clamp-2 mb-4">
                      {quiz.description || "No description"}
                    </p>
                    <div className="flex items-center justify-between text-xs text-text-muted">
                      <span>{quiz.questionCount} questions</span>
                      <span>{quiz.attempts} attempts</span>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>
      )}

      {/* CTA Section */}
      <section className="py-20 px-4">
        <div className="max-w-4xl mx-auto">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            className="relative p-8 sm:p-12 rounded-3xl bg-gradient-to-br from-primary/10 to-secondary/10 border border-primary/20 text-center overflow-hidden"
          >
            <div className="absolute top-0 right-0 w-64 h-64 bg-primary/5 rounded-full blur-[80px]" />
            <div className="absolute bottom-0 left-0 w-64 h-64 bg-secondary/5 rounded-full blur-[80px]" />
            <div className="relative">
              <h2 className="text-3xl sm:text-4xl font-bold mb-4">
                Ready to Get Started?
              </h2>
              <p className="text-text-secondary max-w-xl mx-auto mb-8">
                Join thousands of quiz creators and start building beautiful
                quizzes today. It&apos;s free and takes less than a minute.
              </p>
              <Link
                href="/register"
                className="inline-flex items-center gap-2 px-8 py-3.5 rounded-xl bg-gradient-to-r from-primary to-primary-hover text-white font-semibold hover:shadow-xl hover:shadow-primary/25 transition-all duration-300 transform hover:scale-105"
              >
                Get Started Free
                <ArrowRight className="w-5 h-5" />
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}

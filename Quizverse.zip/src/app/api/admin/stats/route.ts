import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, quizzes, results, categories } from "@/db/schema";
import { getCurrentUser } from "@/lib/auth";
import { count, eq, desc } from "drizzle-orm";

export async function GET() {
  try {
    const user = await getCurrentUser();
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Forbidden" }, { status: 403 });
    }

    const [userCount] = await db.select({ count: count() }).from(users);
    const [quizCount] = await db.select({ count: count() }).from(quizzes);
    const [resultCount] = await db.select({ count: count() }).from(results);
    const [catCount] = await db.select({ count: count() }).from(categories);

    const recentUsers = await db
      .select({
        id: users.id,
        username: users.username,
        email: users.email,
        role: users.role,
        banned: users.banned,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(desc(users.createdAt))
      .limit(20);

    const recentQuizzes = await db
      .select({
        id: quizzes.id,
        title: quizzes.title,
        published: quizzes.published,
        attempts: quizzes.attempts,
        creatorName: users.username,
        createdAt: quizzes.createdAt,
      })
      .from(quizzes)
      .leftJoin(users, eq(quizzes.creatorId, users.id))
      .orderBy(desc(quizzes.createdAt))
      .limit(20);

    return NextResponse.json({
      stats: {
        users: Number(userCount.count),
        quizzes: Number(quizCount.count),
        results: Number(resultCount.count),
        categories: Number(catCount.count),
      },
      recentUsers,
      recentQuizzes,
    });
  } catch (error) {
    console.error("Admin stats error:", error);
    return NextResponse.json(
      { error: "Internal server error" },
      { status: 500 }
    );
  }
}

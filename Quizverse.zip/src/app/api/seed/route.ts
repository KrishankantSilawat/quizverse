import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, categories, quizzes, questions } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { count } from "drizzle-orm";

export async function POST() {
  try {
    // Check if already seeded
    const [userCount] = await db.select({ count: count() }).from(users);
    if (Number(userCount.count) > 0) {
      return NextResponse.json({ message: "Already seeded" });
    }

    // Create admin user
    const adminPass = await hashPassword("admin123");
    const [admin] = await db
      .insert(users)
      .values({
        username: "admin",
        email: "admin@quizverse.app",
        password: adminPass,
        role: "admin",
        bio: "QuizVerse Administrator",
      })
      .returning();

    // Create demo user
    const demoPass = await hashPassword("demo123");
    const [demoUser] = await db
      .insert(users)
      .values({
        username: "demo",
        email: "demo@quizverse.app",
        password: demoPass,
        role: "user",
        bio: "Demo user for testing",
      })
      .returning();

    // Create categories
    const catData = [
      { name: "Programming", icon: "Code", color: "#6C63FF" },
      { name: "Science", icon: "FlaskConical", color: "#00E5FF" },
      { name: "History", icon: "Landmark", color: "#FFB800" },
      { name: "Sports", icon: "Dumbbell", color: "#22c55e" },
      { name: "Movies", icon: "Clapperboard", color: "#ef4444" },
      { name: "Geography", icon: "Globe", color: "#8b5cf6" },
      { name: "Technology", icon: "Cpu", color: "#06b6d4" },
      { name: "Mathematics", icon: "Calculator", color: "#f59e0b" },
    ];

    const cats = await db.insert(categories).values(catData).returning();

    // Create sample quizzes
    const quiz1 = await db
      .insert(quizzes)
      .values({
        title: "JavaScript Fundamentals",
        description:
          "Test your knowledge of JavaScript basics including variables, functions, and data types.",
        categoryId: cats[0].id,
        difficulty: "easy",
        timeLimit: 300,
        published: true,
        creatorId: admin.id,
        attempts: 42,
        rating: 4.5,
      })
      .returning();

    await db.insert(questions).values([
      {
        quizId: quiz1[0].id,
        question: "What is the output of typeof null?",
        optionA: "null",
        optionB: "object",
        optionC: "undefined",
        optionD: "string",
        correctAnswer: "B",
        explanation: 'typeof null returns "object" due to a legacy bug in JavaScript.',
        marks: 1,
        orderIndex: 0,
      },
      {
        quizId: quiz1[0].id,
        question: "Which keyword declares a block-scoped variable?",
        optionA: "var",
        optionB: "let",
        optionC: "const",
        optionD: "Both B and C",
        correctAnswer: "D",
        explanation: "Both let and const declare block-scoped variables.",
        marks: 1,
        orderIndex: 1,
      },
      {
        quizId: quiz1[0].id,
        question: "What does === operator check?",
        optionA: "Value only",
        optionB: "Type only",
        optionC: "Value and type",
        optionD: "Reference",
        correctAnswer: "C",
        explanation: "The strict equality operator checks both value and type.",
        marks: 1,
        orderIndex: 2,
      },
      {
        quizId: quiz1[0].id,
        question: "Which method adds elements to the end of an array?",
        optionA: "push()",
        optionB: "pop()",
        optionC: "shift()",
        optionD: "unshift()",
        correctAnswer: "A",
        explanation: "push() adds one or more elements to the end of an array.",
        marks: 1,
        orderIndex: 3,
      },
      {
        quizId: quiz1[0].id,
        question: "What is a closure in JavaScript?",
        optionA: "A type of loop",
        optionB: "A function that has access to outer scope variables",
        optionC: "A CSS property",
        optionD: "A HTML element",
        correctAnswer: "B",
        explanation: "A closure is a function that retains access to variables from its outer scope.",
        marks: 1,
        orderIndex: 4,
      },
    ]);

    const quiz2 = await db
      .insert(quizzes)
      .values({
        title: "World Geography Challenge",
        description: "How well do you know the world? Test your geography knowledge!",
        categoryId: cats[5].id,
        difficulty: "medium",
        timeLimit: 600,
        published: true,
        creatorId: admin.id,
        attempts: 28,
        rating: 4.2,
      })
      .returning();

    await db.insert(questions).values([
      {
        quizId: quiz2[0].id,
        question: "What is the largest continent by area?",
        optionA: "Africa",
        optionB: "North America",
        optionC: "Asia",
        optionD: "Europe",
        correctAnswer: "C",
        explanation: "Asia is the largest continent at about 44.58 million km².",
        marks: 1,
        orderIndex: 0,
      },
      {
        quizId: quiz2[0].id,
        question: "Which country has the most time zones?",
        optionA: "Russia",
        optionB: "France",
        optionC: "USA",
        optionD: "China",
        correctAnswer: "B",
        explanation: "France has 12 time zones due to its overseas territories.",
        marks: 1,
        orderIndex: 1,
      },
      {
        quizId: quiz2[0].id,
        question: "What is the deepest ocean?",
        optionA: "Atlantic",
        optionB: "Indian",
        optionC: "Arctic",
        optionD: "Pacific",
        correctAnswer: "D",
        explanation: "The Pacific Ocean contains the Mariana Trench, the deepest point on Earth.",
        marks: 1,
        orderIndex: 2,
      },
      {
        quizId: quiz2[0].id,
        question: "Which river is the longest in the world?",
        optionA: "Amazon",
        optionB: "Nile",
        optionC: "Mississippi",
        optionD: "Yangtze",
        correctAnswer: "B",
        explanation: "The Nile River is approximately 6,650 km long.",
        marks: 1,
        orderIndex: 3,
      },
    ]);

    const quiz3 = await db
      .insert(quizzes)
      .values({
        title: "Science & Discovery",
        description: "Explore the wonders of science with this exciting quiz!",
        categoryId: cats[1].id,
        difficulty: "hard",
        timeLimit: 480,
        published: true,
        creatorId: demoUser.id,
        attempts: 15,
        rating: 4.8,
      })
      .returning();

    await db.insert(questions).values([
      {
        quizId: quiz3[0].id,
        question: "What is the speed of light in vacuum?",
        optionA: "3 × 10^6 m/s",
        optionB: "3 × 10^8 m/s",
        optionC: "3 × 10^10 m/s",
        optionD: "3 × 10^4 m/s",
        correctAnswer: "B",
        explanation: "The speed of light in vacuum is approximately 3 × 10^8 meters per second.",
        marks: 2,
        orderIndex: 0,
      },
      {
        quizId: quiz3[0].id,
        question: "What is the chemical symbol for Gold?",
        optionA: "Go",
        optionB: "Gd",
        optionC: "Au",
        optionD: "Ag",
        correctAnswer: "C",
        explanation: "Au comes from the Latin word 'Aurum' meaning gold.",
        marks: 1,
        orderIndex: 1,
      },
      {
        quizId: quiz3[0].id,
        question: "Which planet is known as the Red Planet?",
        optionA: "Venus",
        optionB: "Jupiter",
        optionC: "Mars",
        optionD: "Saturn",
        correctAnswer: "C",
        explanation: "Mars appears red due to iron oxide (rust) on its surface.",
        marks: 1,
        orderIndex: 2,
      },
    ]);

    return NextResponse.json({
      message: "Database seeded successfully!",
      admin: { email: "admin@quizverse.app", password: "admin123" },
      demo: { email: "demo@quizverse.app", password: "demo123" },
    });
  } catch (error) {
    console.error("Seed error:", error);
    return NextResponse.json(
      { error: "Failed to seed database" },
      { status: 500 }
    );
  }
}
